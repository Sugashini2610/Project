<!DOCTYPE html>
<html>
<head>
<title>Pizza Delivery</title>
</head>
<style>
.container{
width: 40%;
height: auto;
border:solid 1px;
margin-left: 5%;
text-align: center;
float: left;
}
.message{
width: 40%;
height: auto;

border:solid 1px;
display: inline-block;
float: right;
margin-right: 5%;

}
label{
width: 100px;
display: inline-block;
margin-left: 5px;
}
.a2{
margin-bottom: 5px;
}
.btn{
margin-bottom: 20px;
}
p{
font-weight: bold;
}
.a5{
margin-left: 10%;
}
</style>
<body>
<div class="container">
<center><h3 class="a1">Leo's Pizza Delivery</h3></center>
<label>Name :</label>
<input type="text" name="name" class="a2" required id="name"><br>
<label>Address :</label>
<input type="text" name="address" class="a2" required id="address"><br>
<label>Town/city :</label>

<input type="text" name="city" class="a2" required id="city"><br>
<label>Postcode :</label>
<input type="text" name="postcode" class="a2" required id="postcode"><br>
<label>Telphone :</label>
<input type="number" name="telephone" class="a2" required id="telephone"><br>
<label>Email :</label>
<input type="text" name="email" class="a2" required id="email">
<p>Toppings</p>
<input type="radio" name="toppings" id="margherita"
value="Margherita"><label>Margherita</label>
<input type="radio" name="toppings" id="seasons" value="Four Seasons"><label>Four
Seasons</label>
<input type="radio" name="toppings" id="meatfeast" value="Meat Feast"><label>Meat
Feast</label><br>

<p>Size</p>
<input type="radio" name="size" id="small" value="Small"><label>Small</label>
<input type="radio" name="size" id="medium" value="Medium"><label>Medium</label>
<input type="radio" name="size" id="large" value="Large"><label>Large</label><br>
<p>Extras</p>
<input type="checkbox" name="extra" id="mushroom"
value="Mushroom"><label>Mushroom</label>
<input type="checkbox" name="extra" id="peppers" value="Green Peppers"><label>Green
Peppers</label>
<input type="checkbox" name="extra" id="anchovies"
value="Anchovies"><label>Anchovies</label><br>
<input type="checkbox" name="extra" id="cheese" value="Extra Cheese"><label>Extra
cheese</label><br><br>

<label>Preferred Delivery Time</label>
<input type="time" name="time" id="time" class="a3"><br><br>

<label>Delivery Instructions</label>
<textarea cols="25" rows="2" id="instructions"
class="a4"></textarea><br><br>
<button id="btn" class="btn">Order</button></br>

</div>
<div class="message">
<center><h3>Delivery Status</h3></center><br>
<label class="a5">Name :</label><span id="dname"></span><br> <br><br>
<label class="a5">Address :</label><span id="dAddress"></span><br> <br><br>
<label class="a5">Town/city :</label><span id="dcity"></span><br> <br><br>
<label class="a5">Postcode :</label><span id="dpostcode"></span><br><br><br>
<label class="a5">Telephone :</label><span id="dtelephone"></span><br><br> <br>
<label class="a5">Email :</label><span id="demail"></span><br> <br>
<label class="a5">Toppings :</label><span id="dtoppings"></span><br> <br>
<label class="a5">Size :</label><span id="dsize"></span><br> <br><br>
<label class="a5">Extras :</label><span id="dextras"></span><br> <br><br>
<label class="a5">Prefered Time :</label><span id="dtime"></span><br> <br>
<label class="a5">Delivery Instructions :</label><span id="dinstructions"></span><br> <br>

</div>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script>
$(document).ready(function(){
$("#btn").on('click',function(){
$name=$("#name").val();
$("#dname").text($name);
$address=$("#address").val();
$("#dAddress").text($address);
$city=$("#city").val();
$("#dcity").text($city);

$postcode=$("#postcode").val();
$("#dpostcode").text($postcode);
$telephone=$("#telephone").val();
$("#dtelephone").text($telephone);
$email=$("#email").val();
$("#demail").text($email);
var toppings=$("input[name='toppings']:checked").val();
$("#dtoppings").text(toppings);
var size=$("input[name='size']:checked").val();
$("#dsize").text(size);
var extras=[];
$("input[name='extra']:checked").each(function(){
extras.push($(this).val());
});
$("#dextras").text(extras);
$time=$("#time").val();
$("#dtime").text($time);
$instructions=$("#instructions").val();
$("#dinstructions").text($instructions);

});
});
</script>
</html>