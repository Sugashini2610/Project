<!DOCTYPE html>
<html>
<head>
<title>COURSE REGISTRATION</title>
</head>
<style>
.container{
width: 40%;
height: auto;
border:solid 1px;
margin-left: 5%;
text-align: center;
float: left;
}
.message{
width: 40%;
height: auto;

border:solid 1px;
display: inline-block;
float: right;
margin-right: 5%;

}
label{
width: 100px;
display: inline-block;
margin-left: 5px;
}
.a2{
margin-bottom: 5px;
}
.btn{
margin-bottom: 20px;
}
p{
font-weight: bold;
}
.a5{
margin-left: 10%;
}
</style>
<body>
<div class="container">
<center><h3 class="a1">COURSE REGISTERATION</h3></center>
<label>Name :</label>
<input type="text" name="name" class="a2" required id="name"><br>
<p>Gender</p>
<input type="radio" name="gender" id="male" value="Male"><label>Male</label>
<input type="radio" name="gender" id="female" value="Female"><label>Female</label> <br>

<p>Courses</p>
<input type="checkbox" name="course" id="c" value="C"><label>C</label>
<input type="checkbox" name="course" id="c++" value="C++"><label>C++</label>
<input type="checkbox" name="course" id="php" value="PHP"><label>PHP</label><br><br>
<input type="checkbox" name="course" id="java" value="Java"><label>Java</label>
<input type="checkbox" name="course" id="py" value="Python"><label>Python</label>
<input type="checkbox" name="course" id="c#" value="C#"><label>C#</label><br><br>

<button id="btn" class="btn">Register Now</button></br>

</div>
<div class="message">
<center><h3>REGISTERED COURSES</h3></center><br>
<p class="a5">Hello! <span id="dname"></span>...</p>
<p class="a5">Your Courses : <span id="dcourses"></span> </p>

</div>
</body>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
$("#btn").click(function(){
var name=$("#name").val();
// var gender=$("input[name='gender']:checked").val();
var courses=[];
$("input[name='course']:checked").each(function(){
courses.push($(this).val());
});
if(name!=" "){
    $.ajax({
        data : {dname: name, dcourses: courses},
        success : function(response){
            $("#dname").text(name);
            $("#dcourses").text(courses.join(", "));
        }
    });

}
});
});
</script>
</html>