<?php
require ("clients.php");
$db=new database();
$my=new client($db);
$users=$my->readdata("radio");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISV5WaRU90FeRpok6YctnYmDr5pNlyT2bRjXh@JhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
integrity="sha384-YvpcrfetY31HB60NNkmXc5s9FDVZLESAA55NDz0xhy9kcIdslK1eN7N6jIez" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<title>DETAILS DISPLAY</title>
</head>
<body>
<nav class="navbar bg-primary" data-bs-theme="dark">
<button style="margin-left:150px;" type="submit"><a href="index.php">INSERT</a></button>
</nav>
<table class="table table-warning">
<thead>
<tr>
<th scope="col">#</th> 
<th scope="col">NAME</th> 
<th scope="col">PHONE</th> 
<th scope="col">GENDER</th>
<th scope="col">DELETE</th>
<th scope="col">UPDATE</th> 
</tr>
</thead>
<tbody>
<?php
foreach($users as $user){
echo "<tr>";
echo "<td>".$user['id']."</td>"; 
echo "<td>" .$user['name']."</td>"; 
echo "<td>".$user['phone']."</td>"; 
echo "<td>".$user['gender']."</td>"; 

echo "<td><button type='submit'><a href='delete.php?id=".$user['id']."'>DELETE</button></a></td>";
echo "<td><button type='submit'><a href='update_form.php?id=".$user['id']."'>UPDATE</button></a></td>"; 
echo "</tr>"; 
}
?>
</tbody>
</table>
</body>
</html>