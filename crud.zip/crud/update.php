<?php
require ("clients.php"); 
$db=new database();
$my=new client($db);
$id=$_POST['id'];
if($_POST['update'] == "update"){
$data=[
    "name"=> $_POST['name'],
    "phone"=> $_POST['phone'],
    "gender"=> $_POST['gender']
];

$result=$my->update("radio",$id, $data);
if ($result) {
echo "UPDATED SUCCESS";
header("Location:table.php");
}else{
echo "UPDATED FAILED";
header("Location:table.php");
}
}
?>