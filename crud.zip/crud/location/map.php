<?php
include "db.php";

// Fetch locations from the database
$sql = "SELECT latitude, longitude FROM locations ORDER BY timestamp DESC";
$result = $conn->query($sql);

$locations = [];
while ($row = $result->fetch_assoc()) {
    $locations[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Google Map with Tracked Locations</title>
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY"></script>
    <script>
        function initMap() {
            var map = new google.maps.Map(document.getElementById("map"), {
                zoom: 10,
                center: { lat: 0, lng: 0 } // Default center
            });

            var locations = <?php echo json_encode($locations); ?>;
            var bounds = new google.maps.LatLngBounds();

            locations.forEach(function(location) {
                var marker = new google.maps.Marker({
                    position: { lat: parseFloat(location.latitude), lng: parseFloat(location.longitude) },
                    map: map
                });
                bounds.extend(marker.position);
            });

            if (locations.length > 0) {
                map.fitBounds(bounds);
            }
        }
    </script>
</head>
<body onload="initMap()">
    <h2>Tracked Locations on Google Map</h2>
    <div id="map" style="width: 100%; height: 500px;"></div>
</body>
</html>
