<?php
include "db.php";  // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO locations (latitude, longitude) VALUES (?, ?)");
    $stmt->bind_param("ss", $latitude, $longitude);
    if ($stmt->execute()) {
        echo "Location stored successfully.";
    } else {
        echo "Error storing location: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
