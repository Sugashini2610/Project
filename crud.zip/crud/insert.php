<?php
require ("clients.php");
$db=new database();
$my=new client($db);
if($_POST['insert'] == "insert"){
$data=[
    "name"=> $_POST['name'],
    "phone"=> $_POST['phone'],
    "gender"=> $_POST['gender']
];

//echo$_POST['age'];



 $result = $my->insertdata("radio",$data);


if ($result) {
echo "INSERTED SUCCESS";
header("Location:table.php");
}else{
    echo "INSERTD FAILED";
header("Location:table.php");
}
}
?>