<?php
require ("config.php");
interface crud{
public function insert($table,$data);
public function user($table);
public function deletedata($table,$id); 
public function getuser($table,$id);
public function update($table,$id, $data);
}
class database implements crud{
        private $connection;
    public function __construct(){
    $this->connection=new mysqli(servername, username, password, db);
    if($this->connection->connect_error){
    die("CONNECTION FAILED:" .$this->connection->connect_error);
    }
    }
    public function insert($table, $data){
    $column=implode(',', array_keys($data));
    $values="'".implode("', '",array_values($data))."'"; 
    $sql="INSERT INTO $table ($column) VALUES ($values)"; 
    echo $sql;
    $result=$this->connection->query($sql);
    if ($result) {
    return $result;
    }else{
    return $result;
    }
    }
    public function user($table){
    $sql="SELECT * FROM $table";
    $users=[];
    $result=$this->connection->query($sql);
    if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){ 
    $users[] = $row;
    }
    }
    return $users;
    }

    public function deletedata($table,$id){
    $sql="DELETE FROM $table WHERE id='$id'";
    echo$sql; 
    $result=$this->connection->query($sql);
    if($result) {
    return "SUCCESS";
    }else{
    return "ERROR";
    }
    }
    public function getuser($table,$id){
    $sql="SELECT * FROM $table WHERE id='$id'";
    $result=$this->connection->query($sql);
    if(mysqli_num_rows($result)==1){
    return mysqli_fetch_assoc($result);
    }else{
    return "ERROR";
    }
    }
    public function update($table,$id, $data){
    $values=[];
    foreach ($data as $key=>$value) {
    $values[]="$key='$value'";
    }
    $setvalue=implode(',', $values);
    $sql="UPDATE $table SET $setvalue WHERE id='$id'"; 
    echo $sql;
    $result=$this->connection->query($sql);
    if($result) {
    return "SUCCESS";
    }else{
    return "ERROR";
    }
    }
}
?>