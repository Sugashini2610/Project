<?php
require ("clients.php");
$db=new database(); 
$my=new client($db);
$id=$_GET['id'];
$row=$my->getuser("dip",$id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> <title>UPDATE</title>
</head>
<style>
table{
margin-top:150px;
border:1px solid;
}
th{
text-align:center;
padding:5px;
border-bottom:1px dashed;
}
td{
padding:15px;
}
</style>
<body>
<form action="update.php" method="POST">
<table align="center">
<thead>
<tr>
<th><h2>CREATE USER</h2></th>
</tr>
</thead>
<tbody>
<tr>
<td><input type="hidden" name="id" id="id" value="<?php echo $row['id']; ?>"></td>
</tr>
<tr>
<td><input type="text" name="name" id="name" value="<?php echo $row['name']; ?>"></td>
</tr>
<tr>
<td><input type="email" name="email" id="email" value="<?php echo $row['email']; ?>" ></td>
</tr>
<tr>
<td><input type="number" name="age" id="age" value="<?php echo $row['age']; ?>"></td>
</tr>
<tr>
<td align="center"><input type="submit" name="update" id="update" value="update"></button></td>
</tr>
</tbody>
</table>
</form>
</body>
</html>