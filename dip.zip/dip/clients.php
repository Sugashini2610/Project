<?php
require ("function.php");
class client{
    private $crud;
    public function __construct(crud $crud){ 
    $this->crud=$crud;
    }
    public function insertdata($table,$data){ 
    //echo"FUNCtion calling";
   // echo$table . $data;
    return $this->crud->insert($table, $data);
    }
    public function readdata($table){
    return $this->crud->user($table);
    }
    public function deletedata($table,$id){
    return $this->crud->deletedata($table,$id);
    }
    public function getuser($table,$id){
    return $this->crud->getuser($table,$id);
    }
    public function update($table, $id, $data) {

    return $this->crud->update($table,$id, $data);
    }
}
?>