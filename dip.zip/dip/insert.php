<?php
require ("clients.php");
$db=new database();
$my=new client($db);
if($_POST['insert'] == "insert"){
$data=[
    "name"=> $_POST['name'],
    "email"=> $_POST['email'],
    "age"=> $_POST['age']
];

//echo$_POST['age'];



 $result = $my->insertdata("dip",$data);


if ($result) {
echo "INSERTED SUCCESS";
header("Location:table.php");
}else{
    echo "INSERTD FAILED";
header("Location:table.php");
}
}
?>