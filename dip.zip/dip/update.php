<?php
require ("clients.php"); 
$db=new database();
$my=new client($db);
$id=$_POST['id'];
if($_POST['update'] == "update"){
$data=[
    "name"=> $_POST['name'],
    "email"=> $_POST['email'],
    "age"=> $_POST['age']
];

$result=$my->update("dip",$id, $data);
if ($result) {
echo "UPDATED SUCCESS";
header("Location:table.php");
}else{
echo "UPDATED FAILED";
header("Location:table.php");
}
}
?>