<?php
require ("clients.php");
$db=new database(); 
$my=new client($db);
$id=$_REQUEST['id'];
 $result=$my->deletedata("dip",$id);
if($result) {
// echo "DELETED SUCCESS";
header("Location:table.php");
}else{
// echo "DELETED FAILED";
header("Location:table.php");
}
?>
