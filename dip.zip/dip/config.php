<?php
define('servername', 'localhost');
define('username','root');
define('password','');
define('db', 'crud_operation');
?>