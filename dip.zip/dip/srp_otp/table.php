<?php
require("clients.php");

// Initialize database
$db = new Database();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST['data'] ?? [];

    foreach ($data as $row) {
        $otp = $row['otp'];
        $mobile = $row['mobile'];

        // Insert data into the database
        if ($db->insertData($otp, $mobile)) {
            echo "Data inserted successfully!";
        } else {
            echo "Failed to insert data.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISV5WaRU90FeRpok6YctnYmDr5pNlyT2bRjXh@JhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
integrity="sha384-YvpcrfetY31HB60NNkmXc5s9FDVZLESAA55NDz0xhy9kcIdslK1eN7N6jIez" crossorigin="anonymous"></script>
<title>Static Table Insert</title>
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center mb-4">Static Table</h2>
    <form method="POST">
        <table class="table table-warning table-bordered">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">OTP</th>
                    <th scope="col">Mobile Number</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>
                        <input type="text" name="data[0][otp]" value="87689" class="form-control">
                    </td>
                    <td>
                        <input type="text" name="data[0][mobile]" value="8906643489" class="form-control">
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>
                        <input type="text" name="data[1][otp]" value="87678" class="form-control">
                    </td>
                    <td>
                        <input type="text" name="data[1][mobile]" value="8906634323" class="form-control">
                    </td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>
                        <input type="text" name="data[2][otp]" value="78859" class="form-control">
                    </td>
                    <td>
                        <input type="text" name="data[2][mobile]" value="8789343489" class="form-control">
                    </td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>
                        <input type="text" name="data[3][otp]" value="65384" class="form-control">
                    </td>
                    <td>
                        <input type="text" name="data[3][mobile]" value="9743934323" class="form-control">
                    </td>
                </tr>
            </tbody>
        </table>
        <div class="text-center">
            <button type="submit" class="btn btn-primary">Insert</button>
        </div>
    </form>
</div>

</body>
</html>
