<?php
// Database connection and CRUD operations

class Database {
    private $connection;
    
    public function __construct() {
        // Database connection setup
        $this->connection = new mysqli("localhost", "root", "", "srp_otp");
        if ($this->connection->connect_error) {
            die("Connection failed: " . $this->connection->connect_error);
        }
    }

    public function insertData($otp, $mobile) {
        // Use prepared statements to prevent SQL injection
        $stmt = $this->connection->prepare("INSERT INTO dip (otp, mobile) VALUES (?, ?)");
        
        // Bind parameters
        $stmt->bind_param("ss", $otp, $mobile); // 'ss' means both are strings

        // Execute the query
        if ($stmt->execute()) {
            return true; // Success
        } else {
            return false; // Error
        }
    }
}

?>
