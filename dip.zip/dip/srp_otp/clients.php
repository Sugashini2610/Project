<?php
require ("function.php");
class client {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function insertData($otp, $mobile) {
        $query = "INSERT INTO dip(otp, mobile) VALUES ($otp, $mobile)";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':otp', $otp);
        $stmt->bindParam(':mobile', $mobile);
        return $stmt->execute();
    }
    
    
}

?>