<?php
// Include database connection
require("config.php");

// Initialize database and client class
$db = new database();
$my = new client($db);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST['data'] ?? [];

    foreach ($data as $row) {
        $otp = $row['otp'];
        $mobile = $row['mobile'];

        // Insert data into the database
        $my->insertData($otp, $mobile);
    }
}
?>
