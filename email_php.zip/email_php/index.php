<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity=" sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" cross origin="anonymous"></script>

<title>Email Sent</title>
</head>
<body>
<form>
<center>
<div><h2>Email</h2>
<input type="text" name="email" id="email" placeholder="Enter Email" required>
<br><br>
<input type="text" name="subject" id="subject" placeholder="Enter Subject" required>
<br><br>
<input type="text" name="message" id="message" placeholder="Enter Message" required>
<br><br>
<button type="button" id="btn" class="">send</button>
</div>
</center>
</form>
</body>
<script>
$(document).ready(function(){ 
  $("#btn").click(function(){
    var email=$('#email').val(); 
    var subject=$('#subject').val(); 
    var message=$('#message').val();
    if (email!="", subject!="") { 
    
      $.ajax({
	   url:"insert.php", 
	   type:"POST",
	   data:{email:email,subject:subject,message:message}, 
	   success:function(response){
        alert("Message sent successfully!!! ");
       }
       
      });
    }
  });  //btn close
});
</script>
</html>