<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<title>Email</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHEKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin=" anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd80VXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmn1MuBnhbgrkm" cross origin="anonymous">
</script>
<style>
input{
display: flex;
width: 100%;
height: 50px;
font-size: 20px;
}
button{
width: 100%;
height: 45px;
}
</style>
</head>
</head>
<body style="background-color: Lightsteelblue;">
<form action="insert.php" method="POST">
<center><h2>Email</h2></center>
<div class="input-group flex-nowrap">
<span class="input-group-text" id="addon-wrapping">email&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> 
<input type="text" class="form-control" placeholder="Enter the Email id" aria-label="username" aria-describedby="addon-wrapping" name="email">
</div>
<br>
<div class="input-group flex-nowrap">
<span class="input-group-text" id="addon-wrapping">subject&nbsp;&nbsp;</span>
<input type="text" class="form-control" placeholder="Enter the subject" aria-label="username" aria-describedby="addon-wrapping" name="subject">
</div>
<br>
<div class="input-group flex-nowrap">
<span class="input-group-text" id="addon-wrapping">message</span>
<input type="text" class="form-control" placeholder="Enter the message" aria-label="username" aria-label-describedby="addon-wrapping" name="message">
</div>
<br>
<br>
<button type="submit" class="btn btn-success" style="font-size: 20px;">SEND</button>
</form>
</body>
</html>
<script>
alert("message send!!!");
</script>
</div>
</form>
</body>
</head>