<?php
$conn=mysqli_connect("localhost","root","","ajax");
$name=$_POST['name'];
$city=$_POST['city'];
$sql="insert into user(name, city) values('$name','$city')"; 
echo $sql;
if (mysqli_query($conn, $sql)){
echo"records added successfully";
}
header('location:table.php');
?>