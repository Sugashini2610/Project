<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>table</title>
</head>
<style>
body{
background-color: aliceblue;
font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; 
padding: 10px 10px 30px;
}
h1{
font-size: 30px;
text-align: center;
}

table, th, td {
border-collapse: collapse; 
border: 2px solid black; 
padding: 10px 20px 10px;

}
table{
width: 90%;
text-align: center;
margin: 10px auto;
}
th{
font-size: large;
font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', 'Geneva';
}
</style> <script>
</script>
<?php
$conn=mysqli_connect("localhost","root","","ajax");
$sql="select * from user";
$sql_exe=mysqli_query($conn, $sql);
$array=mysqli_fetch_row($sql_exe);
?>
<body>
<table border>
<h1>Table CSS</h1>
<thead>
<tr>
<th>SNO</th>
<th>Name</th>
<th>city</th>
<th>View</th>
<th>delete</th>
</thead>
<tbody>
<?php
while ($row=mysqli_fetch_array($sql_exe)){
?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['city']; ?></td>
<td><a href='view.php'><button class='view'><span class='material-symbols-outlined'>view</span></button></td>
<td><a onclick="return confirm('Are you delete this item?')" href="delete.php?id=<?php echo $row['id'];?>"><button class='delete'><span class='material-symbols-outlined'>delete</span></button></td>
</tr>
<?php
}
?>
</tbody>
</table>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" ></script>

<script>
$(document).ready(function() {
   $(".delete").click(function() {
   var sno = $(this).closest("tr"); 
   var id = sno.find("td:eq(0)").html(); 
   $.ajax({
      url: "delete.php?id"=+id,
      method: "DELETE",
      data:{id:id},
   });
alert('working');
window.location.href = "http://localhost/ajax/table.php";
});
});
</script>
</body>
</html>