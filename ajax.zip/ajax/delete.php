<?php
$conn=new mysqli("localhost","root", "", "ajax");

$did=$_REQUEST['id'];
$qr="delete from user where id='$did' ";

echo $qr;
$del=mysqli_query($conn, $qr);
header('location:table.php');
?>