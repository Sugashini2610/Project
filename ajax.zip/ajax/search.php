<?php
$id =$_GET['id'];
$arr_data = [];
$conn=mysqli_connect("localhost","root","","ajax");
$qr = "select * from user where id='$id'";
// echo$qr;
$qr_exe = mysqli_query($conn, $qr);

while ($qr_fet = mysqli_fetch_array($qr_exe)){ 
$arr_data['name'] =$qr_fet['name']; 
$arr_data['city'] =$qr_fet['city'];
}
echo json_encode($arr_data);
?>