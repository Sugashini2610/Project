<?php
$conn=mysqli_connect("localhost","root","","ajax");
$id=$_POST['id'];
$name=$_POST['name'];
$city=$_POST['city'];
$sql="update user set name='$name', city='$city' where id='$id'";
echo $sql;
if (mysqli_query($conn, $sql)){
echo"records added successfully";
}
header('location:table.php');
?>