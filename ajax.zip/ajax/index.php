<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity=" sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" cross origin="anonymous"></script>

<title>Document</title>
</head>
<style>
form {
text-align: center;
border: radius 2px;
box-sizing: border-box;
margin-top: 100px;
border: 100px solid white;
}
button {
background-color: #04AA6D;
color: white;
padding: 14px 20px;
margin: 8px 0;
border: none;
cursor: pointer;
width: 10%;
cursor: pointer;
width: 10%;
}
</style>
<body>
<!-- <form > -->
<div class="container">
<input type="hidden" name="id" id="id">
<div class="mb-3">
<label for="Name" class="form-label">NAME</label>
<input type="text" class="form-control" id="name" name="name"> 
</div><br>
<div class="mb-3">
<label for="city" class="form-label">CITY</label>
<input type="text" class="form-control" id="city" name="city">
</div><br>
<button type="button" id="btn" class="">Insert</button>
<a href="view.php"><button type="button">Search</button></a> 
</div>
<h3 align="center">Manage Student Details</h3>
<input type="button" id="display" value="Display All Data"> 
<div id="responsecontainer" align="center">
</div>
<!--</form>--> 

</body>
<script>
$(document).ready(function(){ 
  $("#btn").click(function(){
    var name=$('#name').val(); 
    var city=$('#city').val(); 
    if (name!="", city!="") { 
      $.ajax({
	   url:"insert.php", 
	   type:"POST",
	   data: {name:name,city:city}, 
	   success:function(response){
       }
      });
    }
  });  //btn close

  $("#display").click(function() {
    $.ajax({
     url: "table.php",
     method: "GET",
     dataType : "html",
     success: function(response){
      $("#responsecontainer").html(response);
     }
    });
  alert("working");
  });


}); //ready close

</script>

</html>














