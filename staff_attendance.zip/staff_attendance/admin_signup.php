<?php
      session_start();

      include("connect.php");
      if($_SERVER['REQUEST_METHOD'] =="POST")
      {
        $email = $_POST['email'];
        $password = $_POST['password'];

        if(!empty($email)&&!empty($password)&&!is_numeric($email))
        {
            $query = "insert into admin(email,password) values ('$email','$password')";

            mysqli_query($conn, $query);

            echo"<script type='text/javascript'>alert('Signed up Successfully')</script>";

        }
        else
        {
            echo"<script type='text/javascript'>alert('Please enter valid information')</script>";

        }
    
      }

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Attendance Monitoring System</title>
  <link rel="stylesheet" type = "text/css" href="static/form.css">
</head>
<body>
<a href="index.php">Home</a>
   <form class="form-staff-signup" name="admin" method="POST" autocomplete="off">
    <h2>
        <span class="title">Staff Attendance Monitoring System</span>
    </h2>
    <div class="form-title">
        <h2>
        <span>Sign Up</span>
        </h2>
    </div><br>
    <div class="form-inputs">
        <div class="input-box">
            <label >Email Address </label><br><br>
            <input type="email" class="input-field" name= "email" placeholder="Email" required>
        </div><br>
        <div class="input-box">
            <label>Password</label><br><br>
            <input type="password" class="input-field" name= "password" placeholder="Password" required><br>
        </div><br><br>
        <input type="checkbox" onclick="myFunction()"> Show Password
    <br><br>
        <div class="btn-box">
        <button type="submit" class="btn-signup" id="staffsignup" value="Sign up">Sign up</button></center>
        </div>
    </div>
   </form>
   <script>
    function myFunction() {
        var x = document.getElementById("myInput");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>
</body>
</html> 