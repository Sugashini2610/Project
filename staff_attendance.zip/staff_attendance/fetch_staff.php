<?php
include("connect.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $department = $_POST['dept'];

    $query = "SELECT name from staff where dept='$department'";
          $result=mysqli_query($conn, $query);
          
        
          while($row=mysqli_fetch_assoc($result)){
            $name = $row["name"];
            $options = '<option value="' . $name . '">' . $name . '</option>';

          }
}
?>
