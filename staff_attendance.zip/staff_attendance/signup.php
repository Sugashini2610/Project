<?php
      session_start();

      include("connect.php");
      if($_SERVER['REQUEST_METHOD'] =="POST")
      {
        $emp_id = $_POST["emp_id"];
        $name = $_POST['name'];
        $dept = $_POST['dept'];
        $gender = $_POST['gender'];
        $phn_no = $_POST['phn_no'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        if(!empty($email)&&!empty($password)&&!is_numeric($email))
        {
            $query = "insert into staff(emp_id,name,dept,gender,phn_no,email,password) values ('$emp_id','$name','$dept','$gender','$phn_no','$email','$password')";

            mysqli_query($conn, $query);
    
            echo"<script type='text/javascript'>alert('Signed up Successfully')</script>";
            
        }
        else
        {
            echo"<script type='text/javascript'>alert('Please enter valid information')</script>";
        }
    
      }

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Attendance Monitoring System</title>
  <link rel="stylesheet" type = "text/css" href="static/form.css">
</head>
<body>
   <form class="form-staff-signup" method="POST" autocomplete="off" >
    <h2>
        <span class="title">Staff Attendance Monitoring System</span>
    </h2>
    <div class="form-title">
        <h2>New staff</h2>
    </div><br>
    <div class="form-inputs-s">
       <div class="input-box">
            <label>Employee ID</label>
            <input type="text" class="input-field" name= "emp_id" placeholder="Employee ID" required>
        </div><br>
        <div class="input-box">
            <label>Name</label>
            <input type="text" class="input-field" name= "name" placeholder="Name" required>
        </div><br>
        <div class="select-btn">
            <label>Department</label>
            <select name="dept" id="dept">
              <option value="Tamil">Tamil</option>
              <option value="English">English</option>
              <option value="History">History</option>
              <option value="Commerce Aided">Commerce Aided</option>
              <option value="Commerce Unaided">Commerce Unaided</option>
              <option value="Mathematics">Mathematics</option>
              <option value="Physics">Physics</option>
              <option value="Chemistry">Chemistry</option>
              <option value="Zoology">Zoology</option>
              <option value="Computer Science">Computer Science</option>
           </select>        
        </div><br>
        <div class="radio-btn-1">
            <label>Gender</label>
            <input type="radio" class="radio-field" name= "gender" value="Male">Male
            <input type="radio" class="radio-field" name= "gender" value="Female">Female  
        </div><br>
        <div class="input-box">
            <label >Phone Number</label>
            <input type="text" class="input-field" name= "phn_no" placeholder="Phone Number" size="10" required>
        </div><br>
        <div class="input-box">
            <label >Email Address </label>
            <input type="email" class="input-field" name= "email" placeholder="Email" required>
        </div><br>
        <div class="input-box">
            <label>Password</label>
            <input type="password" class="input-field" name= "password" placeholder="Password" id="myInput" required><br>
        </div>
        <div class="check-box" > 
        <input type="checkbox" onclick="myFunction()">Show Password
        <br><br></div>
        <div class="btn-box">
          <button type="submit" class="btn-signup" id="staffsignup" value="Sign up">Sign up</button><br>
           Already have an acccount?<a href="login.php">Login</a>
        </div>
    </div>
   </form>
   <script>
    function myFunction() {
        var x = document.getElementById("myInput");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
    </script>

</body>
</html> 