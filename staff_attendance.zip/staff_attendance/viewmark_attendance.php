<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Attendance Monitoring System</title>
  <nav>
    <ul>
        <li><a href="index.php">Home</a></li>
    </ul>
</nav><br>
  <link rel="stylesheet" type="text/css" href="static/styles.css">
</head>

