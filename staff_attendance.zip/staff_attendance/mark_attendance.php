<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Attendance Monitoring System</title>
<link rel="stylesheet" type="text/css" href="static/form.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>

<form class="form-staff-login" id="staff_login" name="attendance" method="POST">
    <h2>
        <span class="title">Staff Attendance Monitoring System</span>
    </h2>
    <div class="form-title">
        <h2>Mark Attendance</h2>
    </div><br>
    <div class="form-inputs-a">
        <div class="input-box">
            <label for="dept">Department</label><br><br>
            <select name="dept" id="dept" onchange="fetchStaffNames()">
                <option value="">Select Department</option>
                <option value="Tamil">Tamil</option>
                <option value="English">English</option>
                <option value="History">History</option>
                <option value="Commerce Aided">Commerce Aided</option>
                <option value="Commerce Unaided">Commerce Unaided</option>
                <option value="Mathematics">Mathematics</option>
                <option value="Physics">Physics</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Zoology">Zoology</option>
                <option value="Computer Science">Computer Science</option>
            </select>        
        </div><br>
        
        <div class="input-box">
            <label for="name">Name</label><br><br>
            <select name="name" id="st_name" required>
                <option value="">Select Staff</option>
                <!-- Staff names will be dynamically populated here -->
            </select>
        </div><br>

        <div class="input-box">
            <label>Date</label><br><br>
            <input type="date" class="input-field" name="date" required>
        </div><br>

        <div class="radio-btn-1">
            <label>Attendance status</label><br><br>
            <input type="radio" class="radio-field" name="status" value="present">Present
            <input type="radio" class="radio-field" name="status" value="absent" checked>Absent<br>
        </div><br>

        <div class="btn-box">
            <button type="submit" class="btn-login" id="markattendance" value="submit" onclick="alert('Attendance Marked Successfully')">Mark attendance</button>
        </div>
    </div>
</form>

<script>
function fetchStaffNames() {
    var dept = document.getElementById("dept").value;
    if (dept != " ") {
       echo ' <?php
include("connect.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $department = $_POST['dept'];

    $query = "SELECT name from staff where dept='$department'";
          $result=mysqli_query($conn, $query);
          
          $options = '<option value="">Select Staff</option>';
    while ($row=mysqli_fetch_assoc($result) ){
        $options .= '<option value="' . $row['name'] . '">' . $row['name'] . '</option>';
    }

    // Close the statement and return the options as a response
    echo $options;
        
}

?>'
    }
}
</script>
</body>
</html>
