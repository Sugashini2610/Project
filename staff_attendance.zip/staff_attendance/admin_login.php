<?php
      session_start();

      include("connect.php");
      if($_SERVER['REQUEST_METHOD'] =="POST")
      {
        $myusername=$_POST['username'];
        $mypassword=$_POST['password'];
        
        if($myusername=='admin' && $mypassword=='admin@123')
        {
            echo "<script>
            alert('Login Successfull');
            window.location.href='admin_dashboard.php';
            </script>";
        }
        else
        {
            echo "<script>
            alert('Invalid credentials');
            window.location.href='admin_login.php';
            </script>";
        }
    
      }

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Attendance Monitoring System</title>
  <link rel="stylesheet" type = "text/css" href="static/form.css">
</head>
<body>

   <form class="form-admin-login" id="admin_login" method="POST" autocomplete="off">
    <h2>
        <span class="title">Staff Attendance Monitoring System</span>
    </h2>
    <div class="form-title">
        <h2> Log In
        </h2>
    </div><br>
    <div class="form-inputs">
        <div class="input-box">
            <label >Username</label><br><br>
            <input type="text" class="input-field" name="username" placeholder="username" required>
        </div><br>
        <div class="input-box">
            <label>Password</label><br><br>
            <input type="password" class="input-field" name="password" placeholder="password" required><br>
        </div><br><br>
        <div class="btn-box">
            <button type="submit" class="btn-login" id="adminlogin" value="Login">Login</button>
        </div>
    </div>
   </form>
</body>
</html> 