<?php
      session_start();

      include("connect.php");
      if($_SERVER['REQUEST_METHOD'] =="POST")
      {
        $name = $_POST['name'];
        $dept = $_POST['dept'];
        $date= $_POST['date'];
        $status = $_POST['status'];

        if(!empty($name)&&!empty($dept))
        {
            $query = "insert into attendance(name,dept,date,status) values ('$name','$dept','$date','$status')";

            mysqli_query($conn, $query); 


        }
        else
        {
            echo"<script type='text/javascript'>alert('Please enter valid information')</script>";

        }
    
      }

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Attendance Monitoring System</title>
  <link rel="stylesheet" type = "text/css" href="static/form.css">
</head>
<body>

   <form class="form-staff-login" id="staff_login" name="attendance" method="POST">
    <h2>
     <span class="title"> Staff Attendance Monitoring System</span>
    </h2>
    <div class="form-title">
        <h2> Mark Attendance
        </h2>
    </div><br>
    <div class="form-inputs-a">
        <div class="input-box">
            <label >Name</label><br><br>
            <input type="text" class="input-field" name="name" placeholder="name" required>
        </div><br>
        <div class="select-btn">
            <label>Department</label><br><br>
            <select name="dept" id="dept">
              <option value="Tamil">Tamil</option>
              <option value="English">English</option>
              <option value="History">History</option>
              <option value="Commerce Aided">Commerce Aided</option>
              <option value="Commerce Unaided">Commerce Unaided</option>
              <option value="Mathematics">Mathematics</option>
              <option value="Physics">Physics</option>
              <option value="Chemistry">Chemistry</option>
              <option value="Zoology">Zoology</option>
              <option value="Computer Science">Computer Science</option>
           </select>        
        </div><br>
        <div class="input-box">
            <label >Date</label><br><br>
            <input type="date" class="input-field" name="date"required>
        </div><br>
        <div class="radio-btn-1">
            <label>Attendance status</label><br><br>
            <input type="radio" class="radio-field" name="status" value="Present" >Present
            <input type="radio" class="radio-field" name="status" value="Absent" checked>Absent<br>
        </div><br>
        <div class="btn-box">
            <button type="submit" class="btn-login" id="markattendance" value="submit" onclick="alert('Attendance Marked Successfully')">Mark attendance</button>
        </div>
    </div>
   </form>
</body>
</html> 