<?php
      include("connect.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Attendance Monitoring System</title>
  <link rel="stylesheet" type = "text/css"  href="static/form.css">
</head>
<body>
   <div class="dash">
     <div class="title"><h2>Staff Attendance Monitoring System</h2></div> 
      <div class="outline">
            <h3><a href="view.php">View Staff List</a></h3><br>
            <h3><a href="view_attendance.php">View Attendance</a></h3><br>
            <h3><a href="view_absentees.php">View Absentees</a></h3>
      </div> 
   </div>    
</body>
</html> 