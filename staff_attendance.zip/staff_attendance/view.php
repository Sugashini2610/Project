<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Attendance Monitoring System</title>
  <style>
  table, th, td {
     border: 1px solid white;
     border-collapse: collapse;
     color: aliceblue;
  }
  th, td {
     background-color: rgb(0, 49, 109);
  }
  </style>
</head>
<body>
    <div class="container">
    <table style="width:100%">
        <thead class = "thead">
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Department</th>
            <th scope="col">Email</th>
            <th scope="col">Phone no</th>
        </tr>
        </thead>
        <tbody>
        <?php
          session_start();

          include("connect.php");

          $query = "SELECT name,dept,email,phn_no from staff";
          $result=mysqli_query($conn, $query);
        
          while($row=mysqli_fetch_assoc($result)){
            $name = $row["name"];
            $dept = $row["dept"];
            $email = $row["email"];
            $phn_no = $row["phn_no"];
            echo" <tr scope='row'>
                <th>$name</th>
                <th>$dept</th>
                <th>$email</th>
                <th>$phn_no</th>
             </tr>";
          }
        ?>
        </tbody>
    </table>
    </div>
</body>
</html> 