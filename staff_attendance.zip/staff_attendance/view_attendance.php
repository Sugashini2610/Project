<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Attendance Monitoring System</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
    }
    .container {
        margin: 50px auto;
        width: 80%;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }
    table, th, td {
        border: 1px solid white;
    }
    th, td {
        padding: 10px;
        text-align: left;
        background-color: rgb(0, 49, 109);
        color: aliceblue;
    }
    th {
        background-color: #00337d;
    }
</style>
</head>
<body>
    <div class="container">
        <form method="POST">
            <label for="date">Select Date:</label>
            <input type="date" id="date" name="date" value="<?php echo isset($_POST['date']) ? $_POST['date'] : date('Y-m-d'); ?>" required>
            <button type="submit">Filter Attendance</button>
        </form>
        <br>
        <table>
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Department</th>
                    <th scope="col">Attendance</th>
                </tr>
            </thead>
            <tbody>
            <?php
                session_start();
                include("connect.php");

                // Get the selected date from the form, default to today's date if not provided
                $selectedDate = isset($_POST['date']) ? $_POST['date'] : date('Y-m-d');

                // Query to get staff with default attendance as "Present" unless marked "Absent"
                $query = "
                    SELECT 
                        s.name, 
                        s.dept, 
                        IFNULL(a.status, 'Present') AS status
                    FROM 
                        staff s
                    LEFT JOIN 
                        attendance a 
                    ON 
                        s.name = a.name 
                    AND 
                        a.date = '$selectedDate'"; // Use the selected date for filtering

                $result = mysqli_query($conn, $query);

                // Loop through each record and output it to the table
                while ($row = mysqli_fetch_assoc($result)) {
                    $name = htmlspecialchars($row['name']);
                    $dept = htmlspecialchars($row['dept']);
                    $status = htmlspecialchars($row['status']);
                    
                    // Output each record as a table row
                    echo "<tr>
                        <td>$name</td>
                        <td>$dept</td>
                        <td>$status</td>
                    </tr>";
                }
            ?>
            </tbody>
        </table>
    </div>
</body>
</html>
