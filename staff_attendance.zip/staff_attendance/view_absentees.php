<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Attendance Monitoring System</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
    }
    .container {
        margin: 50px auto;
        width: 80%;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }
    table, th, td {
        border: 1px solid white;
    }
    th, td {
        padding: 10px;
        text-align: left;
        background-color: rgb(0, 49, 109);
        color: aliceblue;
    }
    th {
        background-color: #00337d;
    }
</style>
</head>
<body>
    <div class="container">
        <form method="POST">
            <label for="date">Select Date:</label>
            <input type="date" id="date" name="date" value="<?php echo isset($_POST['date']) ? $_POST['date'] : date('Y-m-d'); ?>" required>
            <button type="submit">View Absentees</button>
        </form>
        <br>
        <table>
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Department</th>
                </tr>
            </thead>
            <tbody>
            <?php
                session_start();
                include("connect.php");

                // Get the selected date from the form, default to today's date if not provided
                $selectedDate = isset($_POST['date']) ? $_POST['date'] : date('Y-m-d');

                // Query to get staff who are absent on the selected date
                $query = "
                    SELECT 
                        s.name, 
                        s.dept
                    FROM 
                        staff s
                    LEFT JOIN 
                        attendance a 
                    ON 
                        s.name = a.name 
                    AND 
                        a.date = '$selectedDate'
                    WHERE 
                        a.status = 'absent'"; // Only select absent staff for the chosen date

                $result = mysqli_query($conn, $query);

                // Check if any absentees exist
                if (mysqli_num_rows($result) > 0) {
                    // Loop through each absentee and output their data
                    while ($row = mysqli_fetch_assoc($result)) {
                        $name = htmlspecialchars($row['name']);
                        $dept = htmlspecialchars($row['dept']);
                        
                        echo "<tr>
                            <td>$name</td>
                            <td>$dept</td>
                        </tr>";
                    }
                } else {
                    // If no absentees are found, display a message
                    echo "<tr><td colspan='2'>No absentees for the selected date.</td></tr>";
                }
            ?>
            </tbody>
        </table>
    </div>
</body>
</html>
