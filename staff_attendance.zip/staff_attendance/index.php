<?php
    include("connect.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Attendance Monitoring System</title>
  <link rel="stylesheet" type="text/css" href="static/styles.css">
</head>
<body>
<nav>
    <ul>
        <li><a href="index.php">Home</a> | </li>
        <li><a href="admin_login.php">Admin</a> | </li>
        <li><a href="login.php">Staff</a></li>
    </ul>
</nav>

<h1>A.P.C. MAHALAXMI COLLEGE FOR WOMEN</h1>
<h1>Staff Attendance Monitoring System</h1>

</body>
</html>
