<?php

$server = "localhost";
$username = "root";
$password = "";
$db = "attendance";

$conn = new mysqli($server, $username, $password, $db);

?>
<html>
    <body>
        
    </body>
</html>