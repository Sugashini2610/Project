
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Update Customer</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
<style type="text/css">
body {
background: linear-gradient(to left, pink, blue, violet);
}
.container {
width: 600px;
border: 5px solid black;
border-radius: 15px;
padding: 10px 20px 30px;
margin:150px auto;
}
.material-symbols-outlined {
font-family: 'Material Symbols Outlined';
}
.form-group {
margin-bottom: 20px;
}
label{
display: block;
font-size: 1.5em; color: white;
font-weight: bold; margin-bottom: 10px;
}
input {

width:400px;
border: 2px solid black;
border-radius: 15px;
padding: 10px 20px;
margin:10px;
margin-left: 20px;
font-size: 1.6em;
}
.submit-btn {

width:200px;
border: 2px solid black;
border-radius: 15px;
padding: 10px;
margin:10px;
margin-left: 20px;
font-size: 1.8em;
}
.submit-btn:hover {
background-color: black; color: white;
}
</style> 
</head>

<body>
    <div class="container">
    <center><h1>EDIT DETAILS</h1></center>
    <form id="data-form" action="http://localhost/api/customer/update.php" method ="POST">
    <div class="form-group">
    <label class="material-symbols-outlined" for="phone">phone</label>
    <input type="text" name="phone" placeholder="ENTER  NUMBER" required class="s3" id="phone" >
    </div>
    <div class="form-group">
    <label class="material-symbols-outlined" for="otp">otp</label>
    <input type="text" name="otp" placeholder="ENTER OTP " required class="s3" id="otp" >
    </div>
    <center><button type="submit"  class="submit-btn">Update</button></center>
    </form>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script> 
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   

  
<script>
    $(document).ready(function(){
        
        var id = decodeURIComponent("<?php echo $_GET['id']; ?>");
        var phone = decodeURIComponent("<?php echo $_GET['phone']; ?>"); 
        var otp = decodeURIComponent("<?php echo $_GET['otp']; ?>");
        // Populate form fields with the provided customer's details 
        $("#phone").val(phone);
        $("#otp").val(otp);
        $("#data-form").submit(function(event){
            event.preventDefault();
            var jsonData ={
                phone: $("#phone").val(),
                otp: $("#otp").val()
            };
            console.log(jsonData);
            $.ajax({
                url:"http://localhost/api/customer/update.php?id=" + id,
                method:"PUT",
                data:jsonData,
                contentType:"application/json",
                success:function(){ 
                    alert("Data Updated Successfully");
                    window.location.href ="http://localhost/api/customer/display.php";
                },
                error:function(xhr,status,error){
                    alert("Error updating data: " + error);
                }
            });
        });
    });
</script>
</body>
</html>