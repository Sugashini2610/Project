<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   
<script type="text/javascript"> 

$(document).ready(function(){ 
    $('#sub').click(function(){
    var a1=$("#phone").val(); 
    var a2=$("#otp").val();
        alert("SUBMITTED");
        $.ajax({
            url:"",
            method:"POST",
            data:{a1:a1,a2:a2},
            success:function(response){ 
                console.log("working"); 
                 window.location.href ="http://localhost/api/customer/display.php";
            }
        });
    });
});
</script>
<style type="text/css">
body{
    background: linear-gradient(to left,pink,blue,violet);
}
.sl{
width: 600px;
border: 5px solid black;
border-radius: 15px;
padding: 10px 20px 30px;
margin:150px auto;
}
.s2{
color: white;
font-size: 3.0em;
text-align: center;
font-weight: bold;
}
.s3{
width:400px;
border:2px solid black;
border-radius: 15px;
padding: 10px 20px;
margin:10px;
margin-left: 20px;
font-size: 1.6em;
}
#d1{
font-size: 2.0em;
}
.s4{
font-weight: bold;
width:200px;
border:2px solid black;
border-radius: 15px;
padding: 10px;
margin:10px;
margin-left: 20px;
font-size: 1.8em;
}
.s4:hover{
background-color: black;
color: white;
}
</style>
</head>
<body>
<form action="http://localhost/api/customer/create.php" method="post">
<div class="s1">
<h1 class="s2">LOGIN</h1>
<span class="material-symbols-outlined" id="d1" >Phone Number</span><input type="text" name="phone" placeholder="ENTER PHONE NUMBER" required class="s3" id="phone"><br>
<span class="material-symbols-outlined" id="d1">OTP</span><input type="text" name="otp" placeholder="ENTER OTP" required class ="s3" id="otp"><br>
<br>
<center><button type="submit" class="s4" id="sub">LOGIN</button></center>
</div>
</form>
</body>
</html>