<?php
error_reporting(0);

require 'dbconnection.php';

// Helper function for returning error responses
function error422($message) {
    $data = [
        'status' => 422,
        'message' => $message,
    ];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
}

// Store a customer in the database
function storeCustomer($customerInput) {
    global $conn;

    $phone = mysqli_real_escape_string($conn,$customerInput['phone']); 
    $otp = mysqli_real_escape_string($conn,$customerInput['otp']);

    if (empty(trim($phone))) {
        return error422('Enter your phone');
    } elseif (empty(trim($otp))) {
        return error422('Enter your OTP');
    } else {
        $query = "INSERT INTO login(phone, otp)VALUES('$phone', '$otp')";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $data = [
                'status' => 201,
                'message' => 'Customer Created Successfully',
            ];
            header("HTTP/1.0 201 Created");
            return json_encode($data);
        } else {
            $data = [
                'status' => 500,
                'message' => 'Internal Server Error',
            ];
            header("HTTP/1.0 500 Internal Server Error");
            return json_encode($data);
        }
    }
}

// Fetch a single customer
function getCustomer($customerParams) {
    global $conn;

    if (!isset($customerParams['id'])  == null) {
        return error422('Enter your customer ID');
    }

    $customerId = mysqli_real_escape_string($conn, $customerParams['id']); 
    $query = "SELECT * FROM login WHERE id='$customerId' LIMIT 1";
    $result = mysqli_query($conn, $query);

    if ($result) {
        if (mysqli_num_rows($result) == 1) {
            $res = mysqli_fetch_assoc($result);
            $data = [
                'status' => 200,
                'message' => 'Customer Fetched Successfully',
                'data' => $res
            ];
            header("HTTP/1.0 200 OK");
            return json_encode($data);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No Customers Found',
            ];
            header("HTTP/1.0 404 Not Found");
            return json_encode($data);
        }
    } else {
        $data = [
            'status' => 500,
            'message' => 'Internal Server Error',
        ];
        header("HTTP/1.0 500 Internal Server Error");
        return json_encode($data);
    }
}

// Fetch the list of all customers
function getCustomerList() {
    global $conn;

    $query = "SELECT * FROM login";
    $result = mysqli_query($conn, $query);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $res = mysqli_fetch_all($result, MYSQLI_ASSOC);
            $data = [
                'status' => 200,
                'message' => 'Customer List Fetched Successfully',
                'data' => $res
            ];
            header("HTTP/1.0 200 OK");
            return json_encode($data);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No Customers Found',
            ];
            header("HTTP/1.0 404 Not Found");
            return json_encode($data);
        }
    } else {
        $data = [
            'status' => 500,
            'message' => 'Internal Server Error',
        ];
        header("HTTP/1.0 500 Internal Server Error");
        return json_encode($data);
    }
}

// Update a customer
function updateCustomer($customerInput, $customerParams) {
    global $conn;

    if (!isset($customerParams['id']) == null) {
        return error422('Customer ID is not found in URL');
    }

    $customerId = mysqli_real_escape_string($conn, $customerParams['id']); 
    $phone = mysqli_real_escape_string($conn, $customerInput['phone']); 
    $otp = mysqli_real_escape_string($conn, $customerInput['otp']);

    if (empty(trim($phone))) {
        return error422('Enter your phone');
    } elseif (empty(trim($otp))) {
        return error422('Enter your OTP');
    } else {
        $query = "UPDATE login SET phone='$phone', otp='$otp' WHERE id='$customerId' LIMIT 1"; 
        $result = mysqli_query($conn, $query);

        if ($result) {
            $data = [
                'status' => 200,
                'message' => 'Customer Updated Successfully',
            ];
            header("HTTP/1.0 200 OK");
            return json_encode($data);
        } else {
            $data = [
                'status' => 500,
                'message' => 'Internal Server Error',
            ];
            header("HTTP/1.0 500 Internal Server Error");
            return json_encode($data);
        }
    }
}

// Delete a customer
function deleteCustomer($customerParams) {
    global $conn;

    if (!isset($customerParams['id'])  == null) {
        return error422('Customer ID is not found in URL');
    }

    $customerId = mysqli_real_escape_string($conn, $customerParams['id']); 
    $query = "DELETE FROM login WHERE id='$customerId' LIMIT 1"; 
    $result = mysqli_query($conn, $query);

    if ($result) {
        $data = [
            'status' => 200,
            'message' => 'Customer Deleted Successfully',
        ];
        header("HTTP/1.0 200 OK");
        return json_encode($data);
    } else {
        $data = [
            'status' => 404,
            'message' => 'Customer Not Found',
        ];
        header("HTTP/1.0 404 Not Found");
        return json_encode($data);
    }
}
?>
