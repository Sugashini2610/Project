<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ledger Report</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        /* Table Styles */
        .table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden; /* To round the corners of the table */
        }

        .table thead {
            background-color: #007bff;
            color: #ffffff;
        }

        .table th, .table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #dddddd;
        }

                .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .table {
                font-size: 14px;
            }

            .table th, .table td {
                padding: 10px;
            }
        }

        /* Button Styles */
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin: 10px 0;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Input Styles */
        input[type="text"], input[type="date"], select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="text"]:focus, input[type="date"]:focus, select:focus {
            border-color: #007bff;
            outline: none;
        }

        /* Message Styles */
        .message {
            margin: 20px 0;
            padding: 10px;
            border-radius: 5px;
            background-color: #e7f3fe;
            color: #31708f;
            border: 1px solid #bce8f1;
        }
    </style>
</head>
<body>

<h1>Ledger Report</h1>
	<center><p>&nbsp;<span style="color:red;">TO</span>&nbsp;</p></center>

<table class="table">
    <thead>
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Date</th>
            <th scope="col">Particulars</th>
            <th scope="col">Vr.Type</th>
            <th scope="col">Vr.No</th>
            <th scope="col">Debit</th>
            <th scope="col">Credit</th>
        </tr>
    </thead>
    <tbody id="ledgerTableBody">
        		 <tr>
            <td></td>
            <td></td>
            <td></td>
            <td >Total:	</td>
            <td></td>
            <td style='font-weight:800;'>₹ 0</td>
            <td style='font-weight:800;'>₹ 0</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td>To Opening Balance:</td>
            <td></td>
            <td></td>
            <td>₹ 0</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td>By Closing Balance:</td>
            <td></td>
            <td></td>
            <td style='font-weight:800;'>₹ </td>
        </tr>
    </tbody>
  </table>
    </tbody>
</table>

</body>
</html>