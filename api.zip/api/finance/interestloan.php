Balance updated successfully.<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>BALA FINANCE</title>
  <!-- base:css -->
  <link rel="stylesheet" href="vendors/typicons/typicons.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
</head>
<style>
  .form-group .form-control{
    border:0.5px solid black;
	
  }
	

  </style>
<body>
  <!-- <div class="row" id="proBanner">
    <div class="col-12">
      <span class="d-flex align-items-center purchase-popup">
         <p>Get tons of UI components, Plugins, multiple layouts, 20+ sample pages, and more!</p> -->
        <a href="https://bootstrapdash.com/demo/polluxui/template/index.html?utm_source=organic&utm_medium=banner&utm_campaign=free-preview" target="_blank" class="btn download-button purchase-button ml-auto">Upgrade To Pro</a>
        <i class="typcn typcn-delete-outline" id="bannerClose"></i>
      </span>
    </div>
  </div> 
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
   
<nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex justify-content-center">
        <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
          <a class="navbar-brand brand-logo" href="#"><b style="color:white;font-size: 20px;padding: 20px;"> SRI BALAFINANCE</b></a>
          <a class="navbar-brand brand-logo-mini" href="#"><img src="images/logo-mini.svg" alt="logo"/></a>
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="typcn typcn-th-menu"></span>
          </button>
        </div>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <ul class="navbar-nav mr-lg-2">
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link" href="#" data-toggle="dropdown" id="profileDropdown">
              <!-- <img src="images/faces/face5.jpg" alt="profile"/> -->
              <span class="nav-profile-name"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <a class="dropdown-item">
                <i class="typcn typcn-cog-outline text-primary"></i>
                Settings
              </a>
              <a class="dropdown-item">
                <i class="typcn typcn-eject text-primary"></i>
                Logout
              </a>
            </div>
          </li>
          <li class="nav-item nav-user-status dropdown">
              <!-- <p class="mb-0">Last login was 23 hours ago.</p> -->
          </li>
        </ul>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item nav-date dropdown">
            <a class="nav-link d-flex justify-content-center align-items-center" href="javascript:;">
              <h6 class="date mb-0"> Today is 2025 / 01 / 10<br> </h6>
              <i class="typcn typcn-calendar"></i>
            </a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle d-flex justify-content-center align-items-center" id="messageDropdown" href="#" data-toggle="dropdown">
              <i class="typcn typcn-cog-outline mx-0"></i>
              <span class="count"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
              <p class="mb-0 font-weight-normal float-left dropdown-header">Messages</p>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                    <img src="images/faces/face4.jpg" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content flex-grow">
                  <h6 class="preview-subject ellipsis font-weight-normal">David Grey
                  </h6>
                  <p class="font-weight-light small-text text-muted mb-0">
                    The meeting is cancelled
                  </p>
                </div>
              </a>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                    <img src="images/faces/face2.jpg" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content flex-grow">
                  <h6 class="preview-subject ellipsis font-weight-normal">Tim Cook
                  </h6>
                  <p class="font-weight-light small-text text-muted mb-0">
                    New product launch
                  </p>
                </div>
              </a>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                    <img src="images/faces/face3.jpg" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content flex-grow">
                  <h6 class="preview-subject ellipsis font-weight-normal"> Johnson
                  </h6>
                  <p class="font-weight-light small-text text-muted mb-0">
                    Upcoming board meeting
                  </p>
                </div>
              </a>
            </div>
          </li>
          <li class="nav-item dropdown mr-0">
            <a class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center" id="notificationDropdown" href="#" data-toggle="dropdown">
              <i class="typcn typcn-bell mx-0"></i>
              <span class="count"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <p class="mb-0 font-weight-normal float-left dropdown-header">Notifications</p>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-success">
                    <i class="typcn typcn-info mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-normal">Application Error</h6>
                  <p class="font-weight-light small-text mb-0 text-muted">
                    Just now
                  </p>
                </div>
              </a>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-warning">
                    <i class="typcn typcn-cog-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-normal">Settings</h6>
                  <p class="font-weight-light small-text mb-0 text-muted">
                   < Private message
                  </p>
                </div>
              </a>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-info">
                    <i class="typcn typcn-user mx-0"></i> 
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-normal">New user registration</h6>
                  <p class="font-weight-light small-text mb-0 text-muted">
                    2 days ago
                  </p>
                </div>
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="typcn typcn-th-menu"></span>
        </button>
      </div>
    </nav>
      </div>
    </nav>
     <!-- partial -->
    
     <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
      <div class="theme-setting-wrapper">
        <div id="settings-trigger"><i class="typcn typcn-cog-outline"></i></div>
        <div id="theme-settings" class="settings-panel">
          <i class="settings-close typcn typcn-times"></i>
          <p class="settings-heading">SIDEBAR SKINS</p>
          <div class="sidebar-bg-options selected" id="sidebar-light-theme"><div class="img-ss rounded-circle bg-light border mr-3"></div>Light</div>
          <div class="sidebar-bg-options" id="sidebar-dark-theme"><div class="img-ss rounded-circle bg-dark border mr-3"></div>Dark</div>
          <p class="settings-heading mt-2">HEADER SKINS</p>
          <div class="color-tiles mx-0 px-4">
            <div class="tiles success"></div>
            <div class="tiles warning"></div>
            <div class="tiles danger"></div>
            <div class="tiles info"></div>
            <div class="tiles dark"></div>
            <div class="tiles default"></div>
          </div>
        </div>
      </div>
      <div id="right-sidebar" class="settings-panel">
        <i class="settings-close typcn typcn-times"></i>
        <ul class="nav nav-tabs" id="setting-panel" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="todo-tab" data-toggle="tab" href="#todo-section" role="tab" aria-controls="todo-section" aria-expanded="true">TO DO LIST</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="chats-tab" data-toggle="tab" href="#chats-section" role="tab" aria-controls="chats-section">CHATS</a>
          </li>
        </ul>
        <div class="tab-content" id="setting-content">
          <div class="tab-pane fade show active scroll-wrapper" id="todo-section" role="tabpanel" aria-labelledby="todo-section">
            <div class="add-items d-flex px-3 mb-0">
              <form class="form w-100">
                <div class="form-group d-flex">
                  <input type="text" class="form-control todo-list-input" placeholder="Add To-do">
                  <button type="submit" class="add btn btn-primary todo-list-add-btn" id="add-task">Add</button>
                </div>
              </form>
            </div>
            <div class="list-wrapper px-3">
              <ul class="d-flex flex-column-reverse todo-list">
                <li>
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox">
                      Team review meeting at 3.00 PM
                    </label>
                  </div>
                  <i class="remove typcn typcn-delete-outline"></i>
                </li>
                <li>
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox">
                      Prepare for presentation
                    </label>
                  </div>
                  <i class="remove typcn typcn-delete-outline"></i>
                </li>
                <li>
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox">
                      Resolve all the low priority tickets due today
                    </label>
                  </div>
                  <i class="remove typcn typcn-delete-outline"></i>
                </li>
                <li class="completed">
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox" checked>
                      Schedule meeting for next week
                    </label>
                  </div>
                  <i class="remove typcn typcn-delete-outline"></i>
                </li>
                <li class="completed">
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox" checked>
                      Project review
                    </label>
                  </div>
                  <i class="remove typcn typcn-delete-outline"></i>
                </li>
              </ul>
            </div>
            <div class="events py-4 border-bottom px-3">
              <div class="wrapper d-flex mb-2">
                <i class="typcn typcn-media-record-outline text-primary mr-2"></i>
                <span>Feb 11 2018</span>
              </div>
              <p class="mb-0 font-weight-thin text-gray">Creating component page</p>
              <p class="text-gray mb-0">build a js based app</p>
            </div>
            <div class="events pt-4 px-3">
              <div class="wrapper d-flex mb-2">
                <i class="typcn typcn-media-record-outline text-primary mr-2"></i>
                <span>Feb 7 2018</span>
              </div>
              <p class="mb-0 font-weight-thin text-gray">Meeting with Alisa</p>
              <p class="text-gray mb-0 ">Call Sarah Graves</p>
            </div>
          </div>
          <!-- To do section tab ends -->
          <div class="tab-pane fade" id="chats-section" role="tabpanel" aria-labelledby="chats-section">
            <div class="d-flex align-items-center justify-content-between border-bottom">
              <p class="settings-heading border-top-0 mb-3 pl-3 pt-0 border-bottom-0 pb-0">Friends</p>
              <small class="settings-heading border-top-0 mb-3 pt-0 border-bottom-0 pb-0 pr-3 font-weight-normal">See All</small>
            </div>
            <ul class="chat-list">
              <li class="list active">
                <div class="profile"><img src="images/faces/face1.jpg" alt="image"><span class="online"></span></div>
                <div class="info">
                  <p>Thomas Douglas</p>
                  <p>Available</p>
                </div>
                <small class="text-muted my-auto">19 min</small>
              </li>
              <li class="list">
                <div class="profile"><img src="images/faces/face2.jpg" alt="image"><span class="offline"></span></div>
                <div class="info">
                  <div class="wrapper d-flex">
                    <p>Catherine</p>
                  </div>
                  <p>Away</p>
                </div>
                <div class="badge badge-success badge-pill my-auto mx-2">4</div>
                <small class="text-muted my-auto">23 min</small>
              </li>
              <li class="list">
                <div class="profile"><img src="images/faces/face3.jpg" alt="image"><span class="online"></span></div>
                <div class="info">
                  <p>Daniel Russell</p>
                  <p>Available</p>
                </div>
                <small class="text-muted my-auto">14 min</small>
              </li>
              <li class="list">
                <div class="profile"><img src="images/faces/face4.jpg" alt="image"><span class="offline"></span></div>
                <div class="info">
                  <p>James Richardson</p>
                  <p>Away</p>
                </div>
                <small class="text-muted my-auto">2 min</small>
              </li>
              <li class="list">
                <div class="profile"><img src="images/faces/face5.jpg" alt="image"><span class="online"></span></div>
                <div class="info">
                  <p>Madeline Kennedy</p>
                  <p>Available</p>
                </div>
                <small class="text-muted my-auto">5 min</small>
              </li>
              <li class="list">
                <div class="profile"><img src="images/faces/face6.jpg" alt="image"><span class="online"></span></div>
                <div class="info">
                  <p>Sarah Graves</p>
                  <p>Available</p>
                </div>
                <small class="text-muted my-auto">47 min</small>
              </li>
            </ul>
          </div>
          <!-- chat tab ends -->
        </div>
      </div>
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
      <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">  -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<!-- partial:partials/_sidebar.html -->
 <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
         <!-- <li class="nav-item">
            <a class="nav-link" href="index.php">
               <i class="typcn typcn-device-desktop menu-icon"></i> 
              <span class="material-symbols-outlined">
computer
</span>
&nbsp;&nbsp;&nbsp;&nbsp; <span class="menu-title">Dashboard</span>
               <div class="badge badge-danger">new</div> 
            </a>
          </li>-->

          <li class="nav-item">
            <a class="nav-link" href="newcustomer.php">
            <!-- <i class="typcn typcn-document-text menu-icon"></i> -->
            <!-- <i class="bi bi-person-fill-add"></i> -->
            <span class="material-symbols-outlined">
person_add
</span>
            &nbsp;&nbsp;&nbsp;&nbsp;<span class="menu-title">New Customer</span>
              <!-- <div class="badge badge-danger">new</div> -->
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="interestloan.php">
            <!-- <i class="typcn typcn-document-text menu-icon"></i> -->
            <span class="material-symbols-outlined">
percent
</span>
            <i class="bi bi-percent"></i>
            &nbsp;&nbsp;&nbsp;&nbsp;<span class="menu-title">Interest Loan</span>
              <!-- <div class="badge badge-danger">new</div> -->
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="receiptentry.php">
            <!-- <i class="typcn typcn-document-text menu-icon"></i> -->
            <span class="material-symbols-outlined">
receipt
</span>
&nbsp;&nbsp;&nbsp;&nbsp; <span class="menu-title">Receipt Entry</span>
              <!-- <div class="badge badge-danger">new</div> -->
            </a>
          </li>


          <li class="nav-item">
            <a class="nav-link" href="accountsreport.php">
            <!-- <i class="typcn typcn-document-text menu-icon"></i> -->
            <span class="material-symbols-outlined">
lab_profile
</span>
&nbsp;&nbsp;&nbsp;&nbsp; <span class="menu-title">Accounts Reports</span>
              <!-- <div class="badge badge-danger">new</div> -->
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="accountsmaster.php">
            <!-- <i class="typcn typcn-document-text menu-icon"></i> -->
            <span class="material-symbols-outlined">
group
</span>
&nbsp;&nbsp;&nbsp;&nbsp;<span class="menu-title">Accounts Master</span>
              <!-- <div class="badge badge-danger">new</div> -->
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="voucher.php">
            <!-- <i class="typcn typcn-document-text menu-icon"></i> -->
            <span class="material-symbols-outlined">
folder_open
</span>
&nbsp;&nbsp;&nbsp;&nbsp;<span class="menu-title">Voucher</span>
              <!-- <div class="badge badge-danger">new</div> -->
            </a>
          </li>
          

          <li class="nav-item">
            <a class="nav-link" href="outstanding.php">
            <!-- <i class="typcn typcn-document-text menu-icon"></i> -->
            <span class="material-symbols-outlined">
library_books
</span>
&nbsp;&nbsp;&nbsp;&nbsp;  <span class="menu-title">Out Standing</span>
              <!-- <div class="badge badge-danger">new</div> -->
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="closedloanreport.php">
            <!-- <i class="typcn typcn-document-text menu-icon"></i> -->
            <span class="material-symbols-outlined">
checkbook
</span>
&nbsp;&nbsp;&nbsp;&nbsp; <span class="menu-title">Closed Loan Report </span>
              <!-- <div class="badge badge-danger">new</div> -->
            </a>
          </li>

         <!-- <li class="nav-item">
            <a class="nav-link" href="closedloan.php">
            <!-- <i class="typcn typcn-document-text menu-icon"></i> -->
            <span class="material-symbols-outlined">
</span>
&nbsp;&nbsp;&nbsp;&nbsp; <span class="menu-title">  </span>
              <!-- <div class="badge badge-danger">new</div> 
            </a>
          </li>-->

          <!-- <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
              <i class="typcn typcn-document-text menu-icon"></i>
              <span class="menu-title">New Customer</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/newcustomer.php">Buttons</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/dropdowns.html">Dropdowns</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Typography</a></li>
              </ul>
            </div> 
           </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#form-elements" aria-expanded="false" aria-controls="form-elements">
              <i class="typcn typcn-film menu-icon"></i>
              <span class="menu-title">Interst Loan</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="form-elements">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"><a class="nav-link" href="pages/forms/basic_elements.html">Basic Elements</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#charts" aria-expanded="false" aria-controls="charts">
              <i class="typcn typcn-chart-pie-outline menu-icon"></i>
              <span class="menu-title">Accounts</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="charts">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/charts/chartjs.html">ChartJs</a></li>
              </ul>
            </div>
          </li>-->
         <!-- <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#tables" aria-expanded="false" aria-controls="tables">
              <i class="typcn typcn-th-small-outline menu-icon"></i>
              <span class="menu-title">Vouchur</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="tables">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/tables/basic-table.html">Basic table</a></li>
              </ul>
            </div>
          </li>-->
         <!-- <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#icons" aria-expanded="false" aria-controls="icons">
              <i class="typcn typcn-compass menu-icon"></i>
              <span class="menu-title">Outstanding</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="icons">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/icons/mdi.html">Mdi icons</a></li>
              </ul>
            </div>
          </li> -->
          <!-- <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
              <i class="typcn typcn-user-add-outline menu-icon"></i>
              <span class="menu-title">User Pages</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="auth">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/samples/login.html"> Login </a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/samples/register.html"> Register </a></li>
              </ul>
            </div>
          </li> -->
          <!-- <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#error" aria-expanded="false" aria-controls="error">
              <i class="typcn typcn-globe-outline menu-icon"></i>
              <span class="menu-title">Error pages</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="error">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/samples/error-404.html"> 404 </a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/samples/error-500.html"> 500 </a></li>
              </ul>
            </div>
          </li> -->
          <!-- <li class="nav-item">
            <a class="nav-link" href="https://bootstrapdash.com/demo/polluxui-free/docs/documentation.html">
              <i class="typcn typcn-mortar-board menu-icon"></i>
              <span class="menu-title">Documentation</span>
            </a>
          </li> -->

          
        </ul>
      </nav>
      
      <!------>
      <div class="col-10 grid-margin">
              <div class="card">
                <div class="card-body">
				<div class="navbar">
                  <h4 class="card-title">INTEREST LOAN</h4>
					<h6><a href="documentupload.php" align="center">OPEN DOCUMENT</a></h6>
					</div>
                  <form class="form-sample" action="interestloan_insert.php" method="POST" onsubmit="return confirmSubmission();">
                    <p class="card-description">
                      
                    </p>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Loan No</label>
                          <div class="col-sm-9">
							   <input type="hidden" name="loanno_fixed" id="loanno_fixed" value="SRI  - 7" > 
                            <input type="text" name="loanno" id="loanno" class="form-control" placeholder="Loan No" value="SRI  - 7" onClick="this.select();" />
                          </div>
                        </div>
                      </div>
						<div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Customer Name</label>
                          <div class="col-sm-9">
                           <!-- <select name="ledgername" id="ledgername" class="form-control">
								<option value="" disabled selected>Customer Name</option>-->
							  <input list="ledgername" id="customername" name="customername" class="form-control" placeholder="Select Name" >
                         <datalist id="ledgername">
								   <option value='MUTHURAMALINGAM CHITTAI '>MUTHURAMALINGAM CHITTAI </option><option value='DEEPAK CHITTAI'>DEEPAK CHITTAI</option><option value='MUTHURAMALINGAM CHIITAI 1'>MUTHURAMALINGAM CHIITAI 1</option><option value='MARISELVAM CHITTAI '>MARISELVAM CHITTAI </option><option value='DR.SINDHU '>DR.SINDHU </option><option value='RAVIPONPANDI CHITTAI '>RAVIPONPANDI CHITTAI </option><option value='GRACE CHITTAI '>GRACE CHITTAI </option><option value='JOHNSON CHITTAI '>JOHNSON CHITTAI </option><option value='HIMALAYA CHITTAI '>HIMALAYA CHITTAI </option><option value='BAGAVATH SIGN CHITTAI '>BAGAVATH SIGN CHITTAI </option><option value='DEEPAK'>DEEPAK</option><option value='DR VIJAY '>DR VIJAY </option><option value='JEYAKUMAR'>JEYAKUMAR</option><option value=''></option><option value='PRIYA'>PRIYA</option><option value='PRIYA 2'>PRIYA 2</option><option value='LOGANATHAN'>LOGANATHAN</option><option value='PRIYA 3'>PRIYA 3</option><option value='PRIYA 4'>PRIYA 4</option><option value='SEKAR'>SEKAR</option><option value=''></option><option value='VELLATHAI'>VELLATHAI</option>							  </datalist>
                          </div>
                        </div>
                      </div>
                      
                    </div>
                    
                    <div class="row">
                      
						<div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Loan Type</label>
                          <div class="col-sm-9">
                            <!--<input type="text" name="loantype" id="loantype" class="form-control" placeholder="Loan Type"/>-->
							  <select class="form-control" name="loantype" id="loantype" onchange="htn()" >
                            <option value="" disabled selected>Select</option>
                              <option value="Chittai">Chittai</option>
                              <option value="Interest">Interest</option>
							  </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Date</label>
                          <div class="col-sm-9">
                            <input type="date" name="date" id="date" class="form-control" placeholder=""/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Contact Number</label>
                          <div class="col-sm-9">
                          <input type="text"  name="contactno" id="contactno" class="form-control" placeholder="Contact Number"/>
                            <!-- <select class="form-control">
                              <option>Male</option>
                              <option>Female</option>
                            </select> -->
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Loan Amount</label>
                          <div class="col-sm-9">
                            <input type="number" class="form-control" name="loanamount" id="loanamount"  onClick="this.select();" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6" id="div_due_date">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Due Date</label>
                          <div class="col-sm-9">
                          <!--<input type="" class="form-control" name="interest" id="interest" onClick="this.select();" />-->
							  <select class="form-control" name="due_date" id="due_date">
                            <option>Select</option>
                              <option value="7">7</option>
                              <option value="10">10</option>
                              <option value="15">15</option>
                              <option value="30">30</option>
                            </select>
                          </div>
                        </div>
                      </div>
                     
                    <div class="col-md-6" id="div_days">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Days</label>
                          <div class="col-sm-9">
                            <!--<input list="number" name="days" id="days" class="form-control" placeholder=" Select Days">-->
							<input list="days" name="days" id="days" class="form-control" placeholder=" Select Days">
							  <datalist id="days2">
                          <option value="50">
                          <option value="100">
                          <
								  </detalist>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row" >
                      
						
						 <div class="col-md-6" id="div_Interestamt_perday">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Interest Amount PerDay</label>
                          <div class="col-sm-9">
                            <input type="number" name="Interestamt_perday" id="Interestamt_perday" class="form-control" value="0.00" onClick="this.select();"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Interest Taken</label>
                          <div class="col-sm-9">
                            <input type="number" name="interest_taken" id="interest_taken" class="form-control" placeholder="0.00" onClick="this.select();"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row" >
						<div class="col-md-6" id="div_document_charges">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Document Charges</label>
                          <div class="col-sm-9">
                            <input type="number" name="document_charges" id="document_charges" class="form-control" value="0.00" onClick="this.select();"/>
                          </div>
                        </div>
                      </div>
                                           <div class="col-md-6" id="div_collectionamt_day" >
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Collection Amount/Day</label>
                          <div class="col-sm-9">
                            <input type="number" name="collectionamt_day" id="collectionamt_day"class="form-control" placeholder="0.00" onClick="this.select();"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label"> Given Amount</label>
                          <div class="col-sm-9">
                            <input type="number" name="givenamt" id="givenamt" class="form-control" placeholder="0.00" onClick="this.select();" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Payment AC</label>
                          <div class="col-sm-9">
                            <input type="text" name="paymentac" id="paymentac" class="form-control" placeholder="Reference By"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Narration</label>
                          <div class="col-sm-9">
                            <input type="text" name="narration" id="narration" class="form-control" placeholder="Narration"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Details</label>
                          <div class="col-sm-9">
                          <input type="text" name="id_details" id="id_details" class="form-control" placeholder="ID Details"/>

                            <!-- <select class="form-control" name="idproof" >
                            <option>Select</option>
                              <option value="aadharcard">AADHAR CARD</option>
                              <option value="voterid">VOTER ID</option>
                              <option value="pancard">PANCARD</option>
                              <option value="drivinglicense">DRIVING LICENSE</option>
                            </select> -->
                          </div>
                        </div>
                      </div>
                    </div>
                     <div class="row">
                      <!--<div class="col-md-6">
                        <div class="form-group row">
                           <label class="col-sm-3 col-form-label">Due Date</label>
                          <div class="col-sm-9">
                           <!-- <input type="text" name="Due_date" id="Due_date" class="form-control" placeholder=""/>-->
							  <!--<select class="form-control" name="due_date" id="due_date" >
                            <option>Select</option>
                              <option value="7">7</option>
                              <option value="10">10</option>
                              <option value="15">15</option>
                              <option value="30">30</option>
                            </select>
                          </div>
                        </div>
                      </div>-->
                       <div class="col-md-6">
                        <div class="form-group row">
                         <!-- <label class="col-sm-3 col-form-label"></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" />
                          </div>
                        </div>-->
                      </div>
                    </div> 
                    
                   <center> <button type="submit" name="insert" id="insert" class="btn btn-primary mb-2">SAVE</button>
                    <!--<button type="" class="btn btn-info mb-2">Refresh</button>-->
                    <!--<button type="" class="btn btn-info mb-2">ACTIVE</button></center>
                    <a href="documentupload.php"><button type="submit" class="btn btn-danger mb-2">Open Document</a></button> -->


                    <br>
                    <br>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Loan Amount</label>
                          <div class="col-sm-7">
                            <input type="text" name="loanamount1" id="loanamount1" class="form-control" placeholder="0.00" readonly/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">No of Days</label>
                          <div class="col-sm-7">
                            <input type="text" name="nodays" id="nodays" class="form-control" placeholder="0.00"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Interest Amount</label>
                          <div class="col-sm-7">
                            <input type="text" name="interestamnt" id="interestamnt" class="form-control" placeholder="0.00"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">ChittaiTobePaid</label>
                          <div class="col-sm-7">
                            <input type="text" name="chittai_paid" id="chittai_paid" class="form-control" placeholder="0.00"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Penalty Amount</label>
                          <div class="col-sm-7">
                            <input type="text" name="" id="" class="form-control" placeholder="0.00"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Principal Paid</label>
                          <div class="col-sm-7">
                            <input type="text" name="principal_paid" id="principal_paid" class="form-control" placeholder="0.00"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Interest Paid</label>
                          <div class="col-sm-7">
                            <input type="text" name="interestpaid" id="interestpaid" class="form-control" placeholder="0.00"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Principal Balance</label>
                          <div class="col-sm-7">
                            <input type="text" name="principal_bal" id="principal_bal" class="form-control" placeholder="0.00"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Interest Balalnce</label>
                          <div class="col-sm-7">
                            <input type="text" name="interestbal" id="interestbal" class="form-control" placeholder="0.00"/>
                          </div>
                        </div>
                      </div>
                    </div><div class="row">
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Chittai Balance</label>
                          <div class="col-sm-7">
                            <input type="text" name="chittai_bal" id="chittai_bal" class="form-control" placeholder="0.00"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">Balalnce Totoal</label>
                          <div class="col-sm-7">
                            <input type="text" name="balance_total" id="balance_total" class="form-control" placeholder="0.00"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <br>	
                    <br>

					   <button type="button" id="display" style="color:#fff;background:#2c73de; width:100px;border:none;">display</button>
					  
</div>
</div>
</form>

                   
	</div>
		   
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  
                  <!-- <p class="card-description">
                    Add class <code>.table-bordered</code>
                  </p> -->
                  <div class="table-responsive pt-3">
                  <!-- <div class="table-responsive"> -->
					  
					  <div id="response" align="center">
					  </div>
                    
                  </div>
                </div>
              </div>
</div>
</div>


</div>
</html>
<link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>

<script>
	

new DataTable('#example', {
    order: [[2, 'asc']],
    rowGroup: {
        dataSrc: 2
    }
});
</script>


                    
                    <!-- base:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="vendors/chart.js/Chart.min.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>-->
<script type="text/javascript">
    $(document).ready(function(){
		//for display
		$("#display").click(function(){
			var loanno=$("#loanno").val();
			$.ajax({
				url:"table.php",
				method:"GET",
				data: { loanno: loanno },
				dataType:"html",
				success:function(response){
					$("#response").html(response);
				}
			});
			//alert("table working");
		});
		
		
	//for interest
		$("#Interestamt_perday").keyup(function() {
              var perdayinterest = parseFloat($("#Interestamt_perday").val());
			var due_date=$("#due_date").val();
               // var days = 10;
			      if (!isNaN(perdayinterest)) {
                     var interesttaken = perdayinterest * due_date;
                        $("#interest_taken").val(interesttaken);
                  } else {
                        $("#interest_taken").val('');
                  }
			// $("#interest_taken").keyup(function(){//event
	var intamt =parseFloat($("#interest_taken").val());
		var lamt = parseFloat($("#loanamount").val());	 
			var dcharge =parseFloat($("#document_charges").val());	 
		 //alert(intamt+","+lamt+","+dcharge+",");
		 //var gamt = parseInt(lamt)-parseInt(intamt)-parseInt(dcharge);
			 if(!isNaN(intamt) && !isNaN(lamt) && !isNaN(dcharge)){
			 var  gamt=lamt-intamt-dcharge;
		// alert(gamt);
		 $("#givenamt").val(gamt);
			 }else{
				 $("#givenamt").val('');
			 }
	// });
			
			
			
			
			
			
			
			
		   }); //KEY UP CLOSE
		  //for chittai
		$("#days").keyup(function(){
			var days=$("#days").val();
			var loanamount1=$("#loanamount").val();
			
			 if(!isNaN(days) && !isNaN(loanamount1)){
			 var collectionamt_day =loanamount1/days
		// alert(gamt);
		 $("#collectionamt_day").val(collectionamt_day);
			 }else{
				$("#collectionamt_day").val('');
			 }
		});
		$("#interest_taken").keyup(function(){
			var loanamount1=$("#loanamount").val();
			var interest_taken1=$("#interest_taken").val();
			if(!isNaN(interest_taken1)){
				var gamt1=loanamount1-interest_taken1;
				$("#givenamt").val(gamt1);
			}else{
				$("#givenamt").val('');
			}
		});
		//anandcode close
		
		

	// $("#interest_taken").keyup(function(){
		
		
		
     $("#loanno").focus();  //cursor show click avoid
        $("#loanno").keyup(function(){        //event
            // alert("click working");
            var loanno = $("#loanno").val(); 
			
			//alert('var loanno');
            $.ajax({
                url:"info.php",         //url
                method:"GET",           //
                data:{loanno:loanno},
                success:function(response){
                    response = JSON.parse(response);
                   $("#customername").val(response.customername);   //name show input bod
                   
					//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
					$("#loantype").val(response.loantype);
					$("#days").val(response.days);
					$("#interest").val(response.interest);
					$("#document_charges").val(response.document_charges);
					$("#interest_taken").val(response.interest_taken);
					$("#Interestamt_perday").val(response.Interestamt_perday);
					$("#collectionamt_day").val(response.collectionamt_day);
					$("#givenamt").val(response.givenamt);
					$("#paymentac").val(response.paymentac);
					$("#narration").val(response.narration);
					$("#id_details").val(response.id_details);
					//$("#loantype").val(response.loantype);
					$("#contactno").val(response.contactno);



					
									
					
					
					//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
					$("#date").val(response.date);    //amount show input name
                   $("#loanamount").val(response.loanamount);
                   $("#loanamount1").val(response.loanamount);
                   if(response.chittai){
                   $("#principal_paid").val(response.chittai);
                   }else{
                    $("#principal_paid").val(response.principal);
                   }
                   $("#chittai_paid").val(response.chittai);
                  $("#interestpaid").val(response.interest_paid);
					
                
                  


let principal_bal = 0;

if (response.chittai != null && response.chittai != undefined) {
    principal_bal = response.loanamount - response.chittai;
}

if (response.principal !== null && response.principal !== undefined) {
    principal_bal = response.loanamount - response.principal;
}

$("#principal_bal").val(principal_bal);



                  

                  // Calculate date difference
                const currentDate = new Date();
var dateInput = response.date; // Date from AJAX response
var inputDate = new Date(dateInput);
console.log(inputDate);

if (!isNaN(inputDate.getTime())) { // Check for a valid date
    console.log('hi');
    var differenceInMs = inputDate - currentDate;
    var differenceInDays = Math.ceil(differenceInMs / (1000 * 60 * 60 * 24));

    // Add an extra day
    differenceInDays -= 1;

    $("#nodays").val(differenceInDays >= 0 ? differenceInDays : Math.abs(differenceInDays));
} else {
    console.log('hello');
    $("#nodays").val("0");
}

                   // anand code for chittai calculate using loanno
					if (response.loantype === "Chittai") {
                       var loanamount = response.loanamount || 0; 
                       var interest = response.collectionamt_day || 0;
                       var days = parseFloat($("#days").val()) || 0; 
                       var chittaitobepaid = days * interest;
						$("#nodays").val(days || 0);
						$("#interestbal").val(0);
						
						$("#chittai_paid").val(chittaitobepaid || 0);

                       $("#interestamnt").val(interestamount || 0); 
						
						var principalpaid= $("#principal_paid").val(response.chittai);
						
						var chittaibalance= chittaitobepaid - principalpaid;
						
						$("#chittai_bal").val(principal_bal || 0);

                      // var chittaipaid = parseFloat(response.chittai) || 0; 
                      // var chittaibalance = interestamount - chittaipaid;
                       //$("#chittai_bal").val(chittaibalance || 0);
						

                       var interestpaid = response.interest_taken || 0;
                       $("#interestpaid").val(interestpaid);

                       var baltotal = principal_bal;
                       console.log("Loan Amount:", loanamount);
                       console.log("Interest Amount:", interestamount);
                       console.log("Balance Total:", baltotal);
                       $("#balance_total").val(baltotal || 0);
                    } else if (response.loantype === "Interest") {
                       var loanamount = response.loanamount || 0; 
                       var interest = response.Interestamt_perday || 0;
                       var days = parseFloat($("#nodays").val()) || 0; 
                       var interestamount = days * interest;

                       $("#interestamnt").val(interestamount || 0);

                       var interestpaid = parseFloat(response.interest_paid) || 0;
                       $("#interestpaid").val(interestpaid);
    
                       var principalpaid = parseFloat(response.principal) || 0;
                       $("#principal_paid").val(principalpaid);
    
                       var chittaipaid = parseFloat(response.chittai) || 0;
                       $("#chittai_paid").val(chittaipaid);

                       var intbal = interestamount - interestpaid; 
                       console.log("Interest Balance:", intbal);
                       $("#interestbal").val(intbal || 0); 

   
                       $("#chittai_bal").val(0);

                       var bal_total = (loanamount - principalpaid) + (interestamount - interestpaid);
                       $("#balance_total").val(bal_total || 0);
                    } // else if close
					
					

                 }//success close

            });            // alert("Ajax - TEST");
        });  //keyup close
     

		//%%%%%%%%%%%%%NEW CUSTOMER NAME KEYUP%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		   $("#customername").keyup(function(){  
			   var loanno= $("#loanno_fixed").val();//event
            //alert("loano:" +loanno);
			   
            var customername = $("#customername").val(); 
			
			//alert("ABOVE AJAX"+loanno);
            $.ajax({
                url:"info_customername.php",         //url
                method:"GET",           //
                data:{customername:customername},
                success:function(response){
                    response = JSON.parse(response);
            		//console.log("HI RESPONSE");
					  if(response.loanno!=0){
					$("#loanno").val(response.loanno);
					   
				   }else{
					   $("#loanno").val(loanno);
				   }
					//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
					$("#loantype").val(response.loantype);					
					$("#days").val(response.days);
					$("#interest").val(response.interest);
					$("#document_charges").val(response.document_charges);
					$("#interest_taken").val(response.interest_taken);
					$("#Interestamt_perday").val(response.Interestamt_perday);
					$("#collectionamt_day").val(response.collectionamt_day);
					$("#givenamt").val(response.givenamt);
					$("#paymentac").val(response.paymentac);
					$("#narration").val(response.narration);
					$("#id_details").val(response.id_details);
					//$("#loantype").val(response.loantype);
					$("#contactno").val(response.contactno);
					//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
					$("#date").val(response.date);    //amount show input name
                   $("#loanamount").val(response.loanamount);
                   $("#loanamount1").val(response.loanamount);
                   if(response.chittai){
                   $("#principal_paid").val(response.chittai);
                   }else{
                    $("#principal_paid").val(response.principal);
                   }
                   $("#chittai_paid").val(response.chittai);
                  $("#interestpaid").val(response.interest_paid);
					
                
                  


let principal_bal = 0;

if (response.chittai != null && response.chittai != undefined) {
    principal_bal = response.loanamount - response.chittai;
}

if (response.principal !== null && response.principal !== undefined) {
    principal_bal = response.loanamount - response.principal;
}

$("#principal_bal").val(principal_bal);



                  

                  // Calculate date difference
                  const currentDate = new Date();
                        var dateInput = response.date; // Date from AJAX response
                        var inputDate = new Date(dateInput);
					console.log(inputDate);

                        if (inputDate) { // Check for a valid date
							console.log('hi');
                            var differenceInMs = inputDate - currentDate;
                            var differenceInDays = Math.ceil(differenceInMs / (1000 * 60 * 60 * 24));

                            if (differenceInDays >= 0) {
                                $("#nodays").val(` ${differenceInDays}`);
                            } else {
                                $("#nodays").val( `${Math.abs(differenceInDays)}`);
                            }
                        } else {
							console.log('hello');
                            $("#nodays").val("0");
                        }

                   // anand code for chittai calculate using loanno
					if (response.loantype === "Chittai") {
                       var loanamount = response.loanamount || 0; 
                       var interest = response.collectionamt_day || 0;
                       var days = parseFloat($("#days").val()) || 0; 
                       var chittaitobepaid = days * interest;
						$("#nodays").val(days || 0);
						$("#interestbal").val(0);
						
						$("#chittai_paid").val(chittaitobepaid || 0);

                       $("#interestamnt").val(interestamount || 0); 
						
						var principalpaid= $("#principal_paid").val(response.chittai);
						
						var chittaibalance= chittaitobepaid - principalpaid;
						
						$("#chittai_bal").val(principal_bal || 0);

                      // var chittaipaid = parseFloat(response.chittai) || 0; 
                      // var chittaibalance = interestamount - chittaipaid;
                       //$("#chittai_bal").val(chittaibalance || 0);
						

                       var interestpaid = response.interest_taken || 0;
                       $("#interestpaid").val(interestpaid);

                       var baltotal = principal_bal;
                       console.log("Loan Amount:", loanamount);
                       console.log("Interest Amount:", interestamount);
                       console.log("Balance Total:", baltotal);
                       $("#balance_total").val(baltotal || 0);
                    } else if (response.loantype === "Interest") {
                       var loanamount = response.loanamount || 0; 
                       var interest = response.Interestamt_perday || 0;
                       var days = parseFloat($("#nodays").val()) || 0; 
                       var interestamount = days * interest;

                       $("#interestamnt").val(interestamount || 0);

                       var interestpaid = parseFloat(response.interest_paid) || 0;
                       $("#interestpaid").val(interestpaid);
    
                       var principalpaid = parseFloat(response.principal) || 0;
                       $("#principal_paid").val(principalpaid);
    
                       var chittaipaid = parseFloat(response.chittai) || 0;
                       $("#chittai_paid").val(chittaipaid);

                       var intbal = interestamount - interestpaid; 
                       console.log("Interest Balance:", intbal);
                       $("#interestbal").val(intbal || 0); 

   
                       $("#chittai_bal").val(0);

                       var bal_total = (loanamount - principalpaid) + (interestamount - interestpaid);
                       $("#balance_total").val(bal_total || 0);
                    } // else if close
					
					 //alert("response");

                 }//success close
				

            });      
			  // alert("Ajax - TEST");
        });  //keyup close
		
		//%%%%%%%%%%%%%NEW CUSTOMER NAME KEYUP END%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		
		

	
      });  //ready func close
	
function htn() {
    var loantype = document.getElementById("loantype");
    var document_charges = document.getElementById("document_charges");
    var Interestamt_perday = document.getElementById("Interestamt_perday");
    var days = document.getElementById("days");
    var collectionamt_day = document.getElementById("collectionamt_day");
	var due_date=document.getElementById("due_date");
	


    if (loantype.value == "Chittai") {
        // Show the textbox
        div_document_charges.style.display = "none";
		div_Interestamt_perday.style.display = "none";
		div_due_date.style.display="none";
		  div_days.style.display = "block";
		div_collectionamt_day.style.display = "block";	
		$("#interest_taken").prop("readonly", false);
    } else if (loantype.value == "Interest") {
        // Hide the textbox
        div_days.style.display = "none";
		div_collectionamt_day.style.display = "none";
		  div_document_charges.style.display = "block";
		div_Interestamt_perday.style.display = "block";
		$("#interest_taken").prop("readonly", true);

    }  //else if close
	
}   //fun close
	
 </script>

 <script>
        // Get the current date
        const today = new Date();
        
        // Format the date to YYYY-MM-DD
        const formattedDate = today.toISOString().split('T')[0];
        
        // Set the value of the date input to the current date
        document.getElementById('date').value = formattedDate;
    </script>
<script>
        function confirmSubmission() {
            return confirm('Are you sure you want to submit this data?');
        }
    </script>



