
<!-- partial -->
<div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <center><h4 class="card-title">SRI BALA FINANCE CD INTEREST</h4>
                    <h4 class="card-title">CLOSED LOAN REPORT</h4></center>
                  <h4 class="card-title">CHITTAI</h4>
                  <!-- <p class="card-description">
                    Add class <code>.table</code>
                  </p> -->
                  <div class="table-responsive">
                    <table border="2">
                      <thead>
                        <tr>
							<th>S.No</th>
							<th>Loan.No</th>
							<th>Issue Date(loan)</th>
							<th>Party Name</th>
							<th>Loan.Amt</th>
							<th>Days</th>
							<th>Closed Date</th>
							<th>No of Days</th>
							<th>Int.Amt</th>
							<th>Princi.paid</th>
							<th>Int.paid</th>
							<th>princi.bal</th>
							<th>int.bal</th>
							<th>less.Amt</th>
							<th>bal.total</th>
							<th>history</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
<tr><td colspan='15'>No closed loans found.</td></tr>                            	  
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
</div>
</div>


<!-- partial -->
<div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  
                  <h4 class="card-title">DAILY INTEREST</h4>
                  <!-- <p class="card-description">
                    Add class <code>.table</code>
                  </p> -->
                  <div class="table-responsive">
                    <table border="2">
                      <thead>
                        <tr>
                          <th>SINo</th>
                          <th>Loan No</th>
                          <th>Issue Date(loan)</th>
                          <th>PartyName</th>
                          <th>Loan.Amt</th>
                          <th>Days</th>
                          <th>Closed Date</th>
                          <th>NoofDays</th>
                          <th>Int.Amt</th>
                          <th>Princ.paid</th>
                          <th>InterestPaid</th>
                          <th>PrinBalance</th>
                          <th>Int.Balance</th>
                          <th>LessAmount</th>
                          <th>Bal.Total</th>
							<th>Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
							<tr><td colspan='15'>No closed loans found.</td></tr>                            	  
                        
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
</div>
</div>


                    
                    <!-- base:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="vendors/chart.js/Chart.min.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>