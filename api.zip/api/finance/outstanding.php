<!-- partial -->
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
			
        }
        h1 {
            text-align: center;
            color: red;
            margin-bottom: 20px;
        }
        .card {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 4px;
            text-align: left;
            border: 1px solid #ddd;
			font-size:11px;
        }
        th {
            background-color: #f2f2f2;
            color: #000000;
			font-size: 12px;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #e0e0e0;
        }
        .action-button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
        .action-button:hover {
            background-color: #218838;
        }
        .summary-table {
            margin: 20px 0;
            border: 1px solid #ddd;
        }
        .summary-table th, .summary-table td {
            text-align: left;
            padding: 10px;
        }
        .summary-table th {
            background-color: #007bff;
            color: white;
        }
        #balance {
            font-size: 24px;
            color: red;
            text-align: center;
        }
		.float-right {
            float: right;
			font-weight:bold;
			margin-right:20px;
			color:red;
        }
        .info {
            margin-bottom: 15px;
			margin-left:20px;/* Space between each info item */
        }
	@media (max-width: 768px) {
    table {
        font-size: 20px; /* Adjust font size for smaller screens */
    }
    th, td {
        padding: 8px; /* Reduce padding for compact view */
    }
}
    </style>
<div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <center><h1 class="card-title">Principal Paid Details</h1></center>
                  <p class="card-description">
                    CHITTAI<code></code>
                  </p>
                  <div class="table-responsive">
                    <table border="2">
                      <thead>
                        <tr>
                          <th>S.No</th>
                          <th>T.Name</th>
                          <th>L.Date</th>
                          <th>Contact</th>
                          <th>Loan</th>
                          <th>D.charges</th>
                          <th>Int_taken</th>
                          <th>Int/days</th>
                          <th>Given_amt</th>
                          <th>Loan.No</th>
                          <th>No.Of.Days</th>
                          <th>Total_amt</th>
                          <th>Received_Amt</th>
                          <th>Payabale_amt</th>
                          <th>Outstanding</th>
							<th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
						  <tr><td>1</td><td>PRIYA</td><td>2025-01-02</td><td>90090</td><td>₹ 100000</td><td>₹ 0</td><td>₹ 1000</td><td>₹ 1000</td><td>₹ 99000</td><td>4</td><td>100</td><td>₹ 100000</td><td>₹ 3000</td><td style='color:red;'>₹97000</td><td style='color:red;'>₹97000</td><td><button><a href='display.php?loanno=4'><img src='./images/history.png'></a></button></td></tr><tr><td>2</td><td>anand</td><td>2025-01-09</td><td>1000</td><td>₹ 1000000</td><td>₹ 0</td><td>₹ 2000</td><td>₹ 10000</td><td>₹ 998000</td><td>6</td><td>100</td><td>₹ 1000000</td><td>₹ 0</td><td style='color:red;'>₹1000000</td><td style='color:red;'>₹1000000</td><td><button><a href='display.php?loanno=6'><img src='./images/history.png'></a></button></td></tr>  
                      </tbody>
                    </table>
<br>
<br>
<br>
                    <table border="2" align="left">
   <p>சிட்டை </p>
    <tr>
        <th  rowspan="2" style=" text-align:left; width:400px;">
          
			<div class="info">லோன்       :<span class="float-right">₹ 1100000</span></div>
			<div class="info">டாக்குமெண்ட் சார்ஜ்  :<span class="float-right">₹ 0</span></div> 
			<div class="info">வட்டி எடுத்தது:<span class="float-right">₹ 3000</span></div>
			<div class="info">அசல்    :<span class="float-right">₹ 1097000</span></div>
        </th>
        <th rowspan="2" style=" text-align:left; width:500px;"> 
			<div class="info">இன்று வரை கொடுக்க வேண்டியது : <span class="float-right">₹97000</span></div>
			<div class="info">இன்று வரை வாங்கியது :<span class="float-right">₹3000</span></div>
            <div class="info"> இன்று வரை வர வேண்டியது :<span class="float-right">₹97000</span></div>
            <div class="info">மொத்தமாக வர வேண்டியது :<span class="float-right">₹97000</span></div>
        </th> 
    </tr>
</table>
                  </div>
                </div>
              </div>
			  </div>
<br>
<br>
<br>
<br>
<br>
            <!-- partial -->
<div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <!-- <center><h2 class="card-title">Principal Paid Details</h2></center> -->
                  <p class="card-description"><br><br><br>
                    DAILY INTEREST<code></code>
                  </p>
                  <div class="table-responsive">
                    <table border="2">
                      <thead>
                        <tr>
                          <th>S.No</th>
                          <th>T.Name</th>
                          <th>L.Date</th>
                          <th>Contact</th>
                          <th>Loan</th>
                          <th>D.charges</th>
                          <th>Int_taken</th>
                          <th>Int/days</th>
                          <th>Given_amt</th>
                          <th>Loan.No</th>
                          <th>No.Of.Days</th>
                          <th>Total_amt</th>
                          <th>Received_Amt</th>
                          <th>Payabale_amt</th>
                          <th>Outstanding</th>
							<th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
						  <tr><td>1</td><td>VELLATHAI</td><td>2024-12-12</td><td>9843828380</td><td>₹ 100000</td><td>₹ 0</td><td>₹3000</td><td>₹300</td><td>₹97000</td><td>2</td><td>1</td><td>₹100000</td><td>₹2000</td><td style='color:red;'>₹98000</td><td style='color:red;'>₹98000</td><td><button><a href='display.php?loanno=2'><img src='./images/history.png'></a></button></td></tr><tr><td>2</td><td>kumar</td><td>2025-01-01</td><td>123</td><td>₹ 20000</td><td>₹ 1000</td><td>₹2000</td><td>₹200</td><td>₹17000</td><td>5</td><td>1</td><td>₹0</td><td>₹0</td><td style='color:red;'>₹20000</td><td style='color:red;'>₹20000</td><td><button><a href='display.php?loanno=5'><img src='./images/history.png'></a></button></td></tr>                      </tbody>
                    </table>
<br>

                    <table border="2" align="center">
   <p>சீடி </p>
    <tr>
        <th  rowspan="2" style=" text-align:left; width:400px;">
          
			<div class="info">லோன்        :<span class="float-right">₹120000</span></div>
        <div class="info">டாக்குமெண்ட் சார்ஜ்  :<span class="float-right">₹1000</span></div>
        <div class="info">வட்டி எடுத்தது:<span class="float-right">₹5000</span></div>
        <div class="info">அசல்   :<span class="float-right">₹114000</span></div>
        

        </th>
        <th rowspan="2" style=" text-align:left; width:500px;">
            
			<div class="info">இன்று வரை கொடுக்க வேண்டியது   :<span class="float-right">₹6000</span></div>
        <div class="info">இன்று வரை வாங்கியது  : <span class="float-right">₹2000</span></div>
        <div class="info">இன்று வரை வர வேண்டியது  :<span class="float-right">₹98000</span></div>
        <div class="info">மொத்தமாக வர வேண்டியது : <span class="float-right">₹98000</span></div>
           
        </th>
        
    </tr>
</table>
<br>

<table border="2" align="center">
   <p>இரண்டும் சேர்த்து </p>
    <tr>
        <th  rowspan="2" style=" text-align:left; width:400px;">
          
			<div class="info">லோன்     :<span class="float-right">₹1220000</span></div>
			<div class="info">டாக்குமெண்ட் சார்ஜ்  :<span class="float-right">₹1000</span></div>
			<div class="info">வட்டி எடுத்தது :<span class="float-right">₹8000</span></div>
			<div class="info">அசல்  :<span class="float-right">₹1211000</span></div>
        
        </th>
        <th rowspan="2" style=" text-align:left; width:500px;">
            
			<div class="info" >இன்று வரை கொடுக்க வேண்டியது  :<span class="float-right">₹9000</span></div>
        <div class="info">இன்று வரை வாங்கியது  :<span class="float-right">₹5000</span></div>
        <div class="info">இன்று வரை வர வேண்டியது :<span class="float-right">₹195000</span></div>
        <div class="info">மொத்தமாக வர வேண்டியது :<span class="float-right">₹195000</span></div>
           
        </th>       
    </tr>
</table>
                  </div>
                </div>
              </div>
            </div>
</div>
</div>
</div>
</div>        
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>