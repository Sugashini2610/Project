<?php
include 'db.php';

$cust_query = "SELECT COUNT(*) AS total_customer FROM users where role='user'";
$cust_result = mysqli_query($conn, $cust_query);

$cust_row = mysqli_fetch_assoc($cust_result);
$total_customer = $cust_row['total_customer'];

$provider_query = "SELECT COUNT(*) AS total_provider FROM users where role='provider'";
$provider_result = mysqli_query($conn, $provider_query);

$provider_row = mysqli_fetch_assoc($provider_result);
$total_provider = $provider_row['total_provider'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>A to Z Service App - Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    body {
      background-color: #f0f2f5;
    }
    .dashboard-card {
      border-radius: 20px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
      padding: 2rem;
      background-color: white;
      margin-top: 50px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="dashboard-card text-center">
      <div class="text-center mt-4">
        <a href="service_provider.php" class="btn btn-secondary">Service Provider & Service List <?php echo '( '. $total_provider. ' )'?></a>
      </div>
      <div class="text-center mt-4">
        <a href="customer.php" class="btn btn-secondary">Customer List <?php echo '( '. $total_customer. ' )'?></a>
      </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
