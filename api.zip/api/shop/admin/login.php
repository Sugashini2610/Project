<?php
      session_start();
      $email = $_SESSION['email'];
      include("db.php");
      if($_SERVER['REQUEST_METHOD'] =="POST")
      {
        $myemail=$_POST['email'];
        $mypassword=$_POST['password']; 
        if($myemail=='admin@ac.in' && $mypassword=='admin@123')
        {
            echo "<script>
            alert('Login Successfull');
            window.location.href='dashboard.php';
            </script>";
        }
        else
        {
            echo "<script>
            alert('Invalid credentials');
            window.location.href='login.php';
            </script>";
        }  
      }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>A to Z Service App - Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    body {
      background-color: #f0f2f5;
    }
    .login-card {
      border-radius: 20px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
      padding: 2rem;
      background-color: white;
    }
  </style>
</head>
<body>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="login-card">
        <h3 class="text-center mb-4">Login to A to Z Service App</h3>
        <form method="POST">

          <div class="mb-3">
          <label class="form-label"><i class="bi bi-envelope-fill"></i> Email</label>
          <input type="email" name="email" class="form-control" value="<?php echo $email; ?>" readonly>
          </div>

          <div class="mb-3">
            <label class="form-label"><i class="bi bi-shield-lock-fill"></i> Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>

          <button type="submit" class="btn btn-primary w-100 mt-3">Login</button>
        </form>

        <!-- <p class="text-center mt-3">
          Don't have an account? <a href="email_verify.html">Register here</a>
        </p> -->
      </div>
    </div>
  </div>
</div>

</body>
</html>
