<?php
session_start();

// Get the OTP entered by the user
$user_otp = $_POST['otp'];
$real_otp = $_SESSION['otp'];

// Check if the OTP matches
if ($user_otp == $real_otp) {
    // OTP is valid, check if the email already exists in the database

    include 'db.php'; // Database connection
    $email = $_SESSION['email'];

    // Check if the email already exists in the database
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Email exists, fetch the user's role
        $user = mysqli_fetch_assoc($result);
        $role = $user['role'];
        $_SESSION['email']=$email;

        // Redirect to the respective dashboard based on the role
        if ($role == 'provider') {
            $_SESSION['role']=$role;
            header("Location: dashboard.php"); // Redirect to service provider dashboard
        } else {
            $_SESSION['role']=$role;
            header("Location: dashboard.php"); // Redirect to customer dashboard
        }
    } else {
        // Email doesn't exist, redirect to registration page
        header("Location: register.php");
    }
} else {
    // Invalid OTP
    echo "<script>alert('Invalid OTP!'); window.history.back();</script>";
}
?>
