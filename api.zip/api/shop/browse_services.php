<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.html");
    exit();
}

// Include database connection
include 'db.php';

// Fetch services from the database
$query = "SELECT s.id, s.service_name, s.service_desc, u.experience, u.qualification, u.name as provider_name, u.phone 
          FROM services s 
          JOIN users u ON s.provider_email = u.email";

$result = mysqli_query($conn, $query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Browse Services - A to Z Service App</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    body {
      background-color: #f0f2f5;
    }
    .service-card {
      border-radius: 20px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
      padding: 2rem;
      background-color: white;
      margin-bottom: 30px;
    }
  </style>
</head>
<body>

<div class="container mt-5">
  <h2 class="text-center mb-4">Available Services</h2>

  <div class="row">
    <?php if (mysqli_num_rows($result) > 0): ?>
      <?php while ($service = mysqli_fetch_assoc($result)): ?>
        <div class="col-md-6">
          <div class="service-card">
            <h4><i class="bi bi-briefcase-fill"></i> <?php echo htmlspecialchars($service['service_name']); ?></h4>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($service['provider_name']); ?></p>
            <p><strong>Phone:</strong> <?php echo htmlspecialchars($service['phone']); ?></p>
            <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($service['service_desc'])); ?></p>
            <p><strong>Experience:</strong> <?php echo htmlspecialchars($service['experience']); ?> years</p>
            <p><strong>Qualification:</strong> <?php echo htmlspecialchars($service['qualification']); ?></p>
          </div>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <div class="col-12">
        <div class="alert alert-warning text-center">
          No services available at the moment.
        </div>
      </div>
    <?php endif; ?>
  </div>

  <div class="text-center mt-4">
    <a href="dashboard.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
  </div>
</div>

</body>
</html>
