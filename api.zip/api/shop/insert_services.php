<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['role'] != 'provider') {
    header("Location: login.html");
    exit();
}

include 'db.php'; // Connect to database
$email = $_SESSION['email'];

// Fetch provider details including experience and qualification
$result = mysqli_query($conn, "SELECT name, experience, qualification FROM users WHERE email = '$email'");
$provider = mysqli_fetch_assoc($result);

// Handle service addition
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $service_name = mysqli_real_escape_string($conn, $_POST['service_name']);
    $service_desc = mysqli_real_escape_string($conn, $_POST['service_desc']);

    $insert = "INSERT INTO services (provider_email, service_name, service_desc) VALUES ('$email', '$service_name', '$service_desc')";
    mysqli_query($conn, $insert);
    header("Location: manage_services.php"); // Refresh after adding
    exit();
}

// Fetch existing services
$service_result = mysqli_query($conn, "SELECT * FROM services WHERE provider_email = '$email'");
?>