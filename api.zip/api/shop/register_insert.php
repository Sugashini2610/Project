<?php
session_start();
include 'db.php'; // Database connection

if (!isset($_SESSION['email'])) {
    header("Location: email_verify.html");
    exit();
}

$email = $_SESSION['email'];
$name = mysqli_real_escape_string($conn, $_POST['name']);
$phone = mysqli_real_escape_string($conn, $_POST['phone']);
$password = mysqli_real_escape_string($conn, $_POST['password']);
$role = mysqli_real_escape_string($conn, $_POST['role']);
$experience = mysqli_real_escape_string($conn, $_POST['experience']);
$qualification = mysqli_real_escape_string($conn, $_POST['qualification']);

// Insert user details into database
$insert_query = "INSERT INTO users (email, name, phone, password, role, experience, qualification) 
                 VALUES ('$email', '$name', '$phone', '$password', '$role', '$experience', '$qualification')";

if (mysqli_query($conn, $insert_query)) {
    $_SESSION['email'] = $email;
    $_SESSION['role'] = $role;
    header("Location: dashboard.php");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
