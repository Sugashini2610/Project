<?php
$email = $_POST['email'];
// $subject = $_POST['subject'];
// $message = $_POST['message'];
$otp = $_POST['otp'];
use phpmailer\phpmailer\PHPMailer;
use phpmailer\phpmailer\SMTP;
use phpmailer\phpmailer\Exception;

require '/Applications/XAMPP/vendor/phpmailer/phpmailer/src/Exception.php';
require '/Applications/XAMPP/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require '/Applications/XAMPP/vendor/phpmailer/phpmailer/src/SMTP.php';

$mail = new PHPMailer(true);
try{
    $mail->isSMTP();
    $mail->Host = 'SMTP.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'msuga04032001@gmail.com';
    $mail->Password = 'lcpe bvio dyih kjtj';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;

    //Recipients
    $mail->setFrom('from@example.com','suga');
    $mail->addAddress($email);

    $message = "This is your otp".$otp;

    //content
    $mail->isHTML(true);
    $mail->Subject = 'Otp';
    $mail->Body = $message;
    $mail->AltBody = 'Not HTML client';

    $mail->send();
    echo "Message sent successfully!!!";
}catch(Exception $e){
    echo "Message could not be sent. Mailer Error : {$mail->ErrorInfo}";
}
?>