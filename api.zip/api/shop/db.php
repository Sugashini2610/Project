<?php 
// Connect to your database
$servername = "localhost";
$username = "root"; // your db username
$password_db = ""; // your db password
$database = "service_app"; // your database name

$conn = new mysqli($servername, $username, $password_db, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>