<?php
session_start();
if (!isset($_SESSION['email'])) {
  header("Location: email_verify.html");
  exit();
}
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>A to Z Service App - Registration</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    body {
      background-color: #f0f2f5;
    }
    .register-card {
      border-radius: 20px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
      padding: 2rem;
      background-color: white;
    }
  </style>
</head>
<body>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="register-card">
        <h3 class="text-center mb-4">Complete Your Registration</h3>
        <form action="register_insert.php" method="POST">

          <div class="mb-3">
            <label class="form-label"><i class="bi bi-envelope-fill"></i> Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo $email; ?>" readonly>
          </div>

          <div class="mb-3">
            <label class="form-label"><i class="bi bi-person-fill"></i> Full Name</label>
            <input type="text" name="name" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label"><i class="bi bi-telephone-fill"></i> Phone Number</label>
            <input type="tel" name="phone" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label"><i class="bi bi-shield-lock-fill"></i> Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label"><i class="bi bi-person-gear"></i> Role</label>
            <select name="role" class="form-select" required>
              <option value="">Select your role</option>
              <option value="user">Customer</option>
              <option value="provider">Service Provider</option>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label"><i class="bi bi-briefcase-fill"></i> Experience (in years)</label>
            <input type="number" name="experience" class="form-control" min="0" step="1" required>
          </div>

          <div class="mb-3">
            <label class="form-label"><i class="bi bi-bookmark-fill"></i> Qualification</label>
            <input type="text" name="qualification" class="form-control" required>
          </div>

          <button type="submit" class="btn btn-primary w-100 mt-3">Register</button>
        </form>

        <p class="text-center mt-3">
          Already registered? <a href="login.html">Login here</a>
        </p>
      </div>
    </div>
  </div>
</div>

</body>
</html>
