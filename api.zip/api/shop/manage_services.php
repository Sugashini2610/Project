<?php
include 'insert_services.php'
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Services - A to Z Service App</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
  <h2 class="text-center mb-4">Manage Your Services</h2>

  <div class="card mb-4 p-4">
    <h4>Your Experience: <?php echo htmlspecialchars($provider['experience']); ?> years</h4>
    <h4>Your Qualification: <?php echo htmlspecialchars($provider['qualification']); ?></h4>
    <h4>Add New Service</h4>
    <form action="insert_services.php" method="POST">
      <div class="mb-3">
        <label class="form-label">Service Name</label>
        <input type="text" name="service_name" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Service Description</label>
        <textarea name="service_desc" class="form-control" rows="3" required></textarea>
      </div>

      <button type="submit" class="btn btn-primary">Add Service</button>
    </form>
  </div>

  <h4 class="mb-3">Your Services</h4>

  <?php 
  if (mysqli_num_rows($service_result) > 0): 
  ?>
    <ul class="list-group">
      <?php while ($row = mysqli_fetch_assoc($service_result)): ?>
        <li class="list-group-item">
          <h5><?php echo htmlspecialchars($row['service_name']); ?></h5>
          <p><?php echo htmlspecialchars($row['service_desc']); ?></p>
        </li>
      <?php endwhile; ?>
    </ul>
  <?php else: ?>
    <div class="alert alert-info">No services added yet.</div>
  <?php endif; ?>

  <div class="mt-4">
    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
  </div>
</div>

</body>
</html>
