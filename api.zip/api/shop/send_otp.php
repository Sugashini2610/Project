<?php
session_start();
$email = $_POST['email'];

// Generate 6-digit OTP
$otp = rand(100000, 999999);

// Save email and OTP to session
$_SESSION['email'] = $email;
$_SESSION['otp'] = $otp;

// Send email (configure for production)
// $subject = "Your OTP for A to Z Service App";
// $message = "Your OTP is: $otp";
// $headers = "From: no-reply@atozservice.com";



use phpmailer\phpmailer\PHPMailer;
use phpmailer\phpmailer\SMTP;
use phpmailer\phpmailer\Exception;

require '/Applications/XAMPP/vendor/phpmailer/phpmailer/src/Exception.php';
require '/Applications/XAMPP/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require '/Applications/XAMPP/vendor/phpmailer/phpmailer/src/SMTP.php';


if($email=='admin@ac.in'){
    header("Location: http://localhost/api/shop/admin/login.php");
}
else{
$mail = new PHPMailer(true);
try{
    $mail->isSMTP();
    $mail->Host = 'SMTP.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'msuga04032001@gmail.com';
    $mail->Password = 'lcpe bvio dyih kjtj';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;

    //Recipients
    $mail->setFrom('no-reply@atozservice.com','A To Z Services');
    $mail->addAddress($email);

    $message = "Your OTP is: $otp";

    //content
    $mail->isHTML(true);
    $mail->Subject = "Your OTP for A to Z Service App";;
    $mail->Body = $message;
    $mail->AltBody = 'Not HTML client';

    $mail->send();
    echo "Message sent successfully!!!";
    header("Location: verify_otp.html");
}catch(Exception $e){
    echo "Message could not be sent. Mailer Error : {$mail->ErrorInfo}";
}

}
// if (mail($email, $subject, $message, $headers)) {
//   header("Location: verify_otp.html");
// } else {
//   echo "Failed to send OTP. Please try again.";
// }
?>
