<?php
error_reporting(0);

// Allow cross-origin requests and define headers
header('Access-Control-Allow-Origin:*');
header('Content-Type:application/json');
header('Access-Control-Allow-Methods:DELETE');
header('Access-Control-Allow-Headers:Content-Type,Access-Control-Allow-Headers,Authorization,X-Requested-With');

include 'function.php';

// Get the request method
$requestMethod = $_SERVER["REQUEST_METHOD"];

if ($requestMethod == "DELETE") {
    
    // Retrieve input data
    $deleteCustomer = deleteCustomer($_GET);
    echo $deleteCustomer;
} 
else {
    // Handle unsupported request methods
    $data = [
        'status'=>405,
        'message'=>$requestMethod.' Method Not Allowed',
    ];
    header("HTTP/1.0 405 Method Not Allowed");
    echo json_encode($data);
}


?>