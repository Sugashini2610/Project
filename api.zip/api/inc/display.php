<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
<style type="text/css">
body {
background: linear-gradient(to left, pink, blue, violet);
}
table {
border-collapse: collapse;
width: 90%;
padding: 30px 30px;
margin: 50px auto;
}

th, td {
border: 3px solid white;
padding: 10px 10px;
}
th {
background-color: black;
font-size: 2.0em;
color: white;
font-weight: bold;
}

td {
color: white;
font-size: 1.8em;
text-align: center;
}
.edit-btn{
background: none;
border: none;
color: white;
font-weight: bolder;
cursor: pointer;

}
.delete-btn{
background: none;
border: none;
font-weight: bolder;
cursor: pointer;
}
.view-btn{
background: none;
font-weight: bolder;
color: white;
border: none;
color: white;
cursor: pointer;
}
</style>
</head>
<body>
<div class="container">
<table class="table" id="example tr">
<thead>
<tr>
<th>S.NO</th>
<th>NAME</th>
<th>RAM</th>
<th>PRICE</th>
<th>CONNECTION AVAILABLE</th>
<th>EDIT</th>
<th>DELETE</th>
<th>VIEW</th>
</tr>
</thead>
<tbody id="data">
</tbody>
</table>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   
<script type="text/javascript">

function deleteData(id) {
// Assuming your API endpoint for deletion is at "http://localhost/api/inc/delete.php"
var deleteUrl = "http://localhost/api/inc/delete.php?id=" + id;
$.ajax({
url: deleteUrl,
type: "DELETE",
success: function () {
// Refresh the table after successful deletion
refreshTable();
},
error: function (error) {
alert("Error deleting data: " + error.statusText);
}
});
}
function refreshTable() {
fetch("http://localhost/api/inc/read.php").then(
res => {
res.json().then(
data => {
if (data.data.length > 0) {
var temp = "";
data.data.forEach((itemData) => {
temp += "<tr class='w1'>";
temp += "<td>" + itemData.id + "</td>"; 
temp += "<td>" + itemData.name + "</td>"; 
temp += "<td>" + itemData.ram + "</td>";
temp += "<td>" + itemData.price + "</td>";
temp += "<td>" + itemData.connect + "</td>";
temp += "<td><button class='edit-btn' data-id='" + itemData.id + "'><span class='material-symbols-outlined'>edit</span></button></td>";
temp += "<td><button class='delete-btn' data-id='" + itemData.id + "'><span class='material-symbols-outlined'>delete</span></button></td>";
temp += "<td><button class='view-btn' data-id='" + itemData.id + "'><span class='material-symbols-outlined'>visibility</span></button></td></tr>";
});
document.getElementById('data').innerHTML = temp;
}
}
)
}
);
}

$(document).on('click', '.view-btn', function () {
var id = $(this).data('id');
console.log("Edit button clicked with ID:", id); // Add this line to log the ID
var lastClickedCustomer = {
    id: id,
    name: $(this).closest('tr').find('td:eq(1)').text(), 
    ram: $(this).closest('tr').find('td:eq(2)').text(),
    price: $(this).closest('tr').find('td:eq(3)').text(),
    connect: $(this).closest('tr').find('td:eq(4)').text()
};
var confirmation = confirm("Are you sure you want to view this data?");

if (confirmation) {
// Store the last clicked customer's details
// Redirect to form_update.php page with lastClickedCustomer details as query parameters 
window.location.href="http://localhost/api/inc/form.php?id=" + id +
"&name=" + encodeURIComponent(lastClickedCustomer.name)+
"&ram=" + encodeURIComponent(lastClickedCustomer.ram)  +
"&price=" + encodeURIComponent(lastClickedCustomer.price)+
"&connect=" + encodeURIComponent(lastClickedCustomer.connect);

}
});

$(document).on('click', '.delete-btn', function () {
var id = $(this).data('id');
var rowText = $(this).closest('tr').text().trim();
var confirmation = confirm("Are you sure you want to delete this data");
if (confirmation) {
//Call the deleteData() function.
deleteData(id);
}
});
var lastClickedCustomer = {}; // Global variable to store the last clicked customer's details

$(document).on('click', '.edit-btn', function () {
var id = $(this).data('id');
console.log("Edit button clicked with ID:", id); // Add this line to log the ID
// Store the last clicked customer's details
var lastClickedCustomer = {
id: id,
name: $(this).closest('tr').find('td:eq(1)').text(),
ram: $(this).closest('tr').find('td:eq(2)').text(),
price: $(this).closest('tr').find('td:eq(3)').text(),
connect: $(this).closest('tr').find('td:eq(4)').text()
};
var confirmation = confirm("Are you sure you want to edit this data?")
if (confirmation) {
// Redirect to form_update.php page with lastClickedCustomer details as query parameters
window.location.href="http://localhost/api/inc/update_form.php?id=" + id + 
"&name=" + encodeURIComponent(lastClickedCustomer.name) +
"&ram=" + encodeURIComponent(lastClickedCustomer.ram) ;
"&price=" + encodeURIComponent(lastClickedCustomer.price) ;
"&connect=" + encodeURIComponent(lastClickedCustomer.connect) ;
}
});


// Initial table population
refreshTable();

</script>
</body>
</html>