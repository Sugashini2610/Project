<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   
<script type="text/javascript"> 

$(document).ready(function(){ 
    $('#sub').click(function(){
    var a1=$("#name").val(); 
    var a2=$("input[name='ram']:checked").val();
    var a3=$("#price").val();
    var connects=[];
    $("input[name='connect']:checked").each(function(){
        connects.push($(this).val());
    });
    alert(connects);
        alert("SUBMITTED");
        $.ajax({
            url:"",
            method:"POST",
            contentType: "application/json",
            data: JSON.stringify({
                a1: a1,
                a2: a2,
                a3: a3,
                connect: connects // Send array of values
            }),
           // data:{a1:a1,a2:a2,a3:a3,connect:connects},
            success:function(response){ 
                console.log("working");  
                 window.location.href ="http://localhost/api/inc/display.php";
            },
            error:function(xhr,status,error){
                    alert("Error updating data: " + error);
            }
        });
    });
});
</script>
<style type="text/css">
body{
    background: linear-gradient(to left,pink,blue,violet);
}
.sl{
width: 600px;
border: 5px solid black;
border-radius: 15px;
padding: 10px 20px 30px;
margin:150px auto;
}
.s2{
color: white;
font-size: 3.0em;
text-align: center;
font-weight: bold;
}
.s3{
width:400px;
border:2px solid black;
border-radius: 15px;
padding: 10px 20px;
margin:10px;
margin-left: 20px;
font-size: 1.6em;
}
#d1{
font-size: 2.0em;
}
.s4{
font-weight: bold;
width:200px;
border:2px solid black;
border-radius: 15px;
padding: 10px;
margin:10px;
margin-left: 20px;
font-size: 1.8em;
}
.s4:hover{
background-color: black;
color: white;
}
</style>
</head>
<form action="http://localhost/api/inc/create.php" method="post">
<div class="s1">
<h1 class="s2">Laptop</h1>
<span class="material-symbols-outlined" id="d1" >Name</span><input type="text" name="name" placeholder="ENTER NAME" required class="s3" id="name"><br>
<span class="material-symbols-outlined" id="d1">RAM</span><br><input type="radio" name="ram" required class ="s3" value="2GB">2GB<br>
<span class="material-symbols-outlined" id="d1"></span><input type="radio" name="ram" required class ="s3" value="4GB">4GB<br>
<span class="material-symbols-outlined" id="d1"></span><input type="radio" name="ram" required class ="s3" value="8GB">8GB<br>
<span class="material-symbols-outlined" id="d1">Price</span><input type="text" name="price" placeholder="ENTER PRICES" required class ="s3" id="price"><br>
<br>
<span class="material-symbols-outlined" id="d1">Connection Available</span><br><input type="checkbox" name="connect" class ="s3" value="HDMI">HDMI<br>
<span class="material-symbols-outlined" id="d1"></span><input type="checkbox" name="connect"  class ="s3" value="Ethernet">Ethernet<br>
<span class="material-symbols-outlined" id="d1"></span><input type="checkbox" name="connect" class ="s3" value="Headphone jack">Headphone jack<br>
<span class="material-symbols-outlined" id="d1"></span><input type="checkbox" name="connect" class ="s3" value="Wi-Fi">Wi-Fi<br>
<span class="material-symbols-outlined" id="d1"></span><input type="checkbox" name="connect" class ="s3" value="Bluetooth">Bluetooth<br>
<br>
<center><button type="submit" class="s4" id="sub">BUY</button></center>
</div>
</form>

</body>
</html>