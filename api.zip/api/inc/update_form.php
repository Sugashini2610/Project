
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Update Customer</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
<style type="text/css">
body {
background: linear-gradient(to left, pink, blue, violet);
}
.container {
width: 600px;
border: 5px solid black;
border-radius: 15px;
padding: 10px 20px 30px;
margin:150px auto;
}
.material-symbols-outlined {
font-family: 'Material Symbols Outlined';
}
.form-group {
margin-bottom: 20px;
}
label{
display: block;
font-size: 1.5em; color: white;
font-weight: bold; margin-bottom: 10px;
}
input {

width:400px;
border: 2px solid black;
border-radius: 15px;
padding: 10px 20px;
margin:10px;
margin-left: 20px;
font-size: 1.6em;
}
.submit-btn {

width:200px;
border: 2px solid black;
border-radius: 15px;
padding: 10px;
margin:10px;
margin-left: 20px;
font-size: 1.8em;
}
.submit-btn:hover {
background-color: black; color: white;
}
</style> 
</head>

<body>
    <div class="container">
    <center><h1>EDIT DETAILS</h1></center>
    <form id="data-form" action="http://localhost/api/inc/update.php" method ="POST">
    <div class="form-group">
    <label class="material-symbols-outlined" for="name">name</label>
    <input type="text" name="name" placeholder="ENTER  NUMBER" required class="s3" id="name" >
    </div>
    <div class="form-group">
    <label class="material-symbols-outlined" for="ram">ram</label>
    <input type="radio" name="ram" class ="s3" id="ram">2GB<br>
    <input type="radio" name="ram" class ="s3" id="ram">4GB<br>
    <input type="radio" name="ram" required class ="s3" id="ram">8GB<br>
    </div>
    <div class="form-group">
    <label class="material-symbols-outlined" for="price">price</label>
    <input type="text" name="price" placeholder="ENTER price " required class="s3" id="price" >
    </div>
    <div class="form-group">
    <label class="material-symbols-outlined" for="connect">Connection Available</label>
    <input type="checkbox" name="connect" required class ="s3" value="Ethernet">Ethernet<br>
    <input type="checkbox" name="connect" required class ="s3" value="Headphone jack">Headphone jack<br>
    <input type="checkbox" name="connect" required class ="s3" value="Wi-Fi">Wi-Fi<br>
    <input type="checkbox" name="connect" required class ="s3" value="Bluetooth">Bluetooth<br>
    </div>
    <center><button type="submit"  class="submit-btn">Update</button></center>
    </form>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script> 
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   

  
<script>
    $(document).ready(function(){
        
        var id = decodeURIComponent("<?php echo $_GET['id']; ?>");
        var name = decodeURIComponent("<?php echo $_GET['name']; ?>"); 
        var ram = decodeURIComponent("<?php echo $_GET['ram']; ?>");
        var price = decodeURIComponent("<?php echo $_GET['price']; ?>");
        var connect = decodeURIComponent("<?php echo $_GET['connect']; ?>");
    
        // Populate form fields with the provided customer's details 
        $("#name").val(name);
        var ram=$("input[name='ram']:checked").val();
        $("#price").val(price);
        var connect=[];
        $("input[name='connect']:checked").each(function(){   
            connect.push($(this).val());
        });
        $("#data-form").submit(function(event){
            event.preventDefault();
            var jsonData ={
                name: $("#name").val(),
                ram: ram,
               price: $("#price").val(),
               connect: connect
            };
            console.log(jsonData);
            $.ajax({
                url:"http://localhost/api/inc/update.php?id=" + id,
                method:"PUT",
                data:jsonData,
                contentType:"application/json",
                success:function(){ 
                    alert("Data Updated Successfully");
                    window.location.href ="http://localhost/api/inc/display.php";
                },
                error:function(xhr,status,error){
                    alert("Error updating data: " + error);
                }
            });
        });
    });
</script>
</body>
</html>