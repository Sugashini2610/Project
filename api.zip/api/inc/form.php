
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Update Customer</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols +Outlined:opsz, wght, FILL, GRAD@20..48,100..700,0..1,-50..200" /> 
<style type="text/css">
body {
background: linear-gradient(to left, pink, blue, violet);
}
.container {
width: 600px;
border: 5px solid black;
border-radius: 15px;
padding: 10px 20px 30px;
margin:150px auto;
}
.material-symbols-outlined {
font-family: 'Material Symbols Outlined';
}
.form-group {
margin-bottom: 20px;
}
label{
display: block;
font-size: 1.5em; color: white;
font-weight: bold; margin-bottom: 10px;
}
input {

width:400px;
border: 2px solid black;
border-radius: 15px;
padding: 10px 20px;
margin:10px;
margin-left: 20px;
font-size: 1.6em;
}
.submit-btn {

width:200px;
border: 2px solid black;
border-radius: 15px;
padding: 10px;
margin:10px;
margin-left: 20px;
font-size: 1.8em;
}
.submit-btn:hover {
background-color: black; color: white;
}
</style> 
</head>

<body>
    <div class="container">
    <center><h1>LAPTOP DETAILS</h1></center>
    <form id="data-form">
    <div class="form-group">
    <label class="material-symbols-outlined" for="name">Name</label>
    <input type="text" name="name" placeholder="ENTER  NUMBER" required class="s3" id="name" readonly>
    </div>
    <div class="form-group">
    <label class="material-symbols-outlined" for="ram">RAM</label>
    <input type="text" name="ram" placeholder="ENTER RAM " required class="s3" id="ram" readonly>
    </div>
    <div class="form-group">
    <label class="material-symbols-outlined" for="price">Price</label>
    <input type="text" name="price" placeholder="ENTER PRICE " required class="s3" id="price" readonly>
    </div>
    <div class="form-group">
    <label class="material-symbols-outlined" for="connect">Connection Available</label>
    <input type="text" name="connect" placeholder="ENTER CONNECTION" required class="s3" id="connect" readonly>
    </div>
    <center><button type="submit" id="back-btn" class="submit-btn">BACK</button></center>
    </form>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   
      
<script>
    $(document).ready(function(){
        
        var id = decodeURIComponent("<?php echo $_GET['id']; ?>");
        var name = decodeURIComponent("<?php echo $_GET['name']; ?>"); 
        var ram = decodeURIComponent("<?php echo $_GET['ram']; ?>");
        var price = decodeURIComponent("<?php echo $_GET['price']; ?>");
        var connect = decodeURIComponent("<?php echo $_GET['connect']; ?>");
        // Populate form fields with the provided customer's details 
        $("#name").val(name);
        $("#ram").val(ram);
        $("#price").val(price);
        $("#connect").val(connect);
    $("#back-btn").click(function(){
    window.history.go(-1);
    });
    });
</script>
</body>
</html>