<?php
error_reporting(0);

require 'dbconnection.php';

// Helper function for returning error responses
function error422($message) {
    $data = [
        'status' => 422,
        'message' => $message,
    ];
    header("HTTP/1.0 422 Unprocessable Entity");
    echo json_encode($data);
    exit();
}

// Store a customer in the database
function storeCustomer($customerInput) {
    global $conn;

    $name = mysqli_real_escape_string($conn,$customerInput['name']); 
    $ram = mysqli_real_escape_string($conn,$customerInput['ram']);
    $price = mysqli_real_escape_string($conn,$customerInput['price']);
    $connect = mysqli_real_escape_string($conn,$customerInput['connect']);

    if (empty(trim($name))) {
        return error422('Enter your name');
    } elseif (empty(trim($ram))) {
        return error422('Enter your RAM');
    }elseif (empty(trim($price))) {
        return error422('Enter your price');
    }else {
        $query = "INSERT INTO laptop(name, ram, price, connect) VALUES ('$name', '$ram', '$price', '$connect');";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $data = [
                'status' => 201,
                'message' => 'Customer Created Successfully',
            ];
            header("HTTP/1.0 201 Created");
            return json_encode($data);
        } else {
            $data = [
                'status' => 500,
                'message' => 'Internal Server Error',
            ];
            header("HTTP/1.0 500 Internal Server Error");
            return json_encode($data);
        }
    }
}

// Fetch a single customer
function getCustomer($customerParams) {
    global $conn;

    if (!isset($customerParams['id'])  == null) {
        return error422('Enter your customer ID');
    }

    $customerId = mysqli_real_escape_string($conn, $customerParams['id']); 
    $query = "SELECT * FROM laptop WHERE id='$customerId' LIMIT 1";
    $result = mysqli_query($conn, $query);

    if ($result) {
        if (mysqli_num_rows($result) == 1) {
            $res = mysqli_fetch_assoc($result);
            $data = [
                'status' => 200,
                'message' => 'Customer Fetched Successfully',
                'data' => $res
            ];
            header("HTTP/1.0 200 OK");
            return json_encode($data);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No Customers Found',
            ];
            header("HTTP/1.0 404 Not Found");
            return json_encode($data);
        }
    } else {
        $data = [
            'status' => 500,
            'message' => 'Internal Server Error',
        ];
        header("HTTP/1.0 500 Internal Server Error");
        return json_encode($data);
    }
}

// Fetch the list of all customers
function getCustomerList() {
    global $conn;

    $query = "SELECT * FROM laptop";
    $result = mysqli_query($conn, $query);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $res = mysqli_fetch_all($result, MYSQLI_ASSOC);
            $data = [
                'status' => 200,
                'message' => 'Customer List Fetched Successfully',
                'data' => $res
            ];
            header("HTTP/1.0 200 OK");
            return json_encode($data);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No Customers Found',
            ];
            header("HTTP/1.0 404 Not Found");
            return json_encode($data);
        }
    } else {
        $data = [
            'status' => 500,
            'message' => 'Internal Server Error',
        ];
        header("HTTP/1.0 500 Internal Server Error");
        return json_encode($data);
    }
}

// Update a customer
function updateCustomer($customerInput, $customerParams) {
    global $conn;

    if (!isset($customerParams['id']) == null) {
        return error422('Customer ID is not found in URL');
    }

    $customerId = mysqli_real_escape_string($conn, $customerParams['id']); 
    $name = mysqli_real_escape_string($conn, $customerInput['name']); 
    $ram = mysqli_real_escape_string($conn, $customerInput['ram']);
    $price = mysqli_real_escape_string($conn, $customerInput['price']);
    $connect = mysqli_real_escape_string($conn, $customerInput['connect']);

    if (empty(trim($name))) {
        return error422('Enter your name');
    } elseif (empty(trim($ram))) {
        return error422('Enter your RAM');
    }elseif (empty(trim($price))) {
        return error422('Enter your Price');
    } elseif (empty(trim($connect))) {
        return error422('Enter your Connection');
    }  else {
        $query = "UPDATE laptop SET name='$name', ram='$ram', price='$price', connect='$connect' WHERE id='$customerId' LIMIT 1"; 
        $result = mysqli_query($conn, $query);

        if ($result) {
            $data = [
                'status' => 200,
                'message' => 'Customer Updated Successfully',
            ];
            header("HTTP/1.0 200 OK");
            return json_encode($data);
        } else {
            $data = [
                'status' => 500,
                'message' => 'Internal Server Error',
            ];
            header("HTTP/1.0 500 Internal Server Error");
            return json_encode($data);
        }
    }
}

// Delete a customer
function deleteCustomer($customerParams) {
    global $conn;

    if (!isset($customerParams['id'])  == null) {
        return error422('Customer ID is not found in URL');
    }

    $customerId = mysqli_real_escape_string($conn, $customerParams['id']); 
    $query = "DELETE FROM laptop WHERE id='$customerId' LIMIT 1"; 
    $result = mysqli_query($conn, $query);

    if ($result) {
        $data = [
            'status' => 200,
            'message' => 'Customer Deleted Successfully',
        ];
        header("HTTP/1.0 200 OK");
        return json_encode($data);
    } else {
        $data = [
            'status' => 404,
            'message' => 'Customer Not Found',
        ];
        header("HTTP/1.0 404 Not Found");
        return json_encode($data);
    }
}
?>
