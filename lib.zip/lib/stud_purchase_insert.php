<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get posted arrays
    $names = $_POST['name'];
    $dates = $_POST['p1'];         // date
    // $bill_nos = $_POST['p2'];      // bill no
    $card_nos = $_POST['card_no']; 
    $ids = $_POST['p3'];           // accession no (book id)
    $titles = $_POST['p4'];        // title
    $authors = $_POST['p5'];       // author
    $categories = $_POST['p6'];    // category
    $publishers = $_POST['p7'];    // publisher
    $costs = $_POST['p8'];         // cost
    // $purchased_from = $_POST['purchased_from'];

    $count = count($ids); // Total number of books in the array

    for ($i = 0; $i < $count; $i++) {
        // Escape input values to prevent SQL injection
        $name = mysqli_real_escape_string($conn, $names[$i]);
        $date = mysqli_real_escape_string($conn, $dates[$i]);
        // $bill_no = mysqli_real_escape_string($conn, $bill_nos[$i]);
        $card_no = mysqli_real_escape_string($conn, $card_nos[$i]);
        $id = mysqli_real_escape_string($conn, $ids[$i]);
        $title = mysqli_real_escape_string($conn, $titles[$i]);
        $author = mysqli_real_escape_string($conn, $authors[$i]);
        $category = mysqli_real_escape_string($conn, $categories[$i]);
        $publisher = mysqli_real_escape_string($conn, $publishers[$i]);
        $cost = mysqli_real_escape_string($conn, $costs[$i]);

        // 1. Insert into `books` table
        $book_sql = "INSERT INTO books (id, title, author, category, publisher, cost) 
                     VALUES ('$id', '$title', '$author', '$category', '$publisher', '$cost')";
        mysqli_query($conn, $book_sql);

        // 2. Insert into `purchase` table
        $purchase_sql = "INSERT INTO student_purchase (name, date, card_no, book_id) 
                         VALUES ('$name', '$date', '$card_no', '$id')";
        mysqli_query($conn, $purchase_sql);
    }

    echo "success";
} else {
    echo "Invalid request";
}
?>
