<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">


  <!-- Main CSS -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">


</head>

<body class="about-page">

<?php 
  include "nav.php";
?>

  <main class="main">
  <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
               </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Book List<br></li>
          </ol>
        </div>
      </nav>
    </div>
      <div class="container py-5">
      <div class="text-center mb-4">
        <h2 class="fw-bold">Book List</h2>
      </div>
      </div>
      <div class="table-container" style="padding: 10px;">
          <table id="daybook-table" class="table table-bordered table-striped" style="width:auto;padding: 10px;">
            <thead class="table-dark">
              <tr>
                <th>Acc No.</th>
                <th>Title</th>
                <th>Author</th>
                <th>Subject</th>
                <th>Edition</th>
                <th>Volume</th>
                <th>Category</th>
                <th>Publisher</th>
                <th>Year</th>
                <th>Rack</th>
                <th>ISBN</th>
                <th>Cost</th>
                <th>Status</th>
                <th>Edit</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
    <?php 
      include 'db.php'; 
      $query = "SELECT books.*, book_issues.student_id, book_issues.student_name, book_issues.issue_date, book_issues.due_date,  book_issues.return_date 
                FROM books 
                LEFT JOIN book_issues ON books.id = book_issues.id ";
      $result = mysqli_query($conn, $query);
    
      while ($row = mysqli_fetch_assoc($result)) {
          $status = "Available";
          $status_class = "btn-success"; // Green for Available
          $button_disabled = "disabled";
          $issue_date = strtotime($row['issue_date']);
          $due_date = strtotime($row['due_date']);
          $return_date = strtotime($row['return_date']);
          $current_date = strtotime(date("Y-m-d"));
          $days_overdue = ($current_date - $due_date) / (60 * 60 * 24);
        if ($return_date=="") {
          if (!empty($row['issue_date']) && !empty($row['due_date'])) {
             $button_disabled = "";
              if ($issue_date <= $due_date) {
                  $status = "Issued";
                  $status_class = "btn-warning"; // Yellow for Issued
              }
              if ($due_date < $current_date ) {
                 $status = "Pending";
                  $status_class = "btn-danger"; // Red for Pending
              }
              if ($days_overdue >= 30) {
                  $status = "Long Term Pending";
                  $status_class = "btn-light text-danger"; // Light red for Long Term Pending
              }
          } 
        }
          echo "<tr>
                  <td>{$row['id']}</td>
                  <td>{$row['title']}</td>
                  <td>{$row['author']}</td>
                  <td>{$row['subject']}</td>
                  <td>{$row['edition']}</td>
                  <td>{$row['volume']}</td>
                  <td>{$row['category']}</td>
                  <td>{$row['publisher']}</td>
                  <td>{$row['year']}</td>
                  <td>{$row['location_rack']}</td>
                  <td>{$row['isbn']}</td>
                  <td>{$row['cost']}</td>
                  <td>
                    <button class='btn $status_class' data-bs-toggle='modal' data-bs-target='#bookModal{$row['id']}' $button_disabled>$status</button>
                  </td>
                  <td>
                    <a href='edit.php?id={$row['id']}' class='text-primary'><i class='bi bi-pencil-square fs-5'></i></a>
                  </td>
                  <td>
                    <a href='#' class='text-danger delete' data-id='{$row['id']}'><i class='bi bi-trash fs-5'></i></a>
                  </td>
                </tr>";

          // Modal for student details
          echo "<div class='modal fade' id='bookModal{$row['id']}' tabindex='-1' aria-labelledby='modalLabel{$row['id']}' aria-hidden='true'>
                  <div class='modal-dialog'>
                    <div class='modal-content'>
                      <div class='modal-header'>
                        <h5 class='modal-title' id='modalLabel{$row['id']}'>Book Issue Details</h5>
                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                      </div>
                      <div class='modal-body'>
                      <p><strong>Card No:</strong> {$row['student_id']}</p>
                      <p><strong>Student Name:</strong> {$row['student_name']}</p>
                      <p><strong>Issue Date:</strong> {$row['issue_date']}</p>
                      <p><strong>Due Date:</strong> {$row['due_date']}</p>
                      </div>
                    </div>
                  </div>
                </div>";
      }
    ?>
  </tbody>

          </table>
          </div>
      </div>
    </div>
  </main>

  <?php include "footer.php"; ?>

  <!-- Bootstrap JS -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" ></script>


  <!-- jQuery (Required for DataTables) -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>

<script>
	$(document).ready(function() {
	$('#daybook-table').DataTable({
            "pageLength": 10,  // Show 5 entries per page
            "lengthMenu": [ 10, 25, 50, 100],  // Options for entries per page
			      "searching": false,  // Disable search
            "ordering": false,  // Disable sorting
            "info": false 
        });

  $(".delete").click(function() {
    if (!confirm("Are you sure you want to delete this book?")) return;

    var id = $(this).data("id");
    
    $.ajax({
      url: "delete.php",
      method: "POST",
      data: { id: id },
      success: function(response) {
        alert("Book deleted successfully");
        location.reload(); // Reload the table
      },
      error: function() {
        alert("Error deleting the book");
      }
    });
  });
});
</script>

</body>
</html>
