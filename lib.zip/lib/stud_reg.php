<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

  <!-- Main CSS -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body class="about-page">
  
<?php 
  include "nav.php";
 ?>
  <main class="main">
  <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
               </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Student Registration<br></li>
          </ol>
        </div>
      </nav>
    </div>
    <div class="container py-5">
      <div class="text-center mb-4">
        <h1 class="fw-bold">Student Registration</h1>
      </div>
      <!-- <div class="row g-3">
            <div class="col-md-2" style="padding: 10px;">
              <label for="date" class="form-label">Date</label>
              <input type="date" class="form-control" name="date" required>
            </div>
     </div> -->
      <div class="card shadow p-4">
        <form method="post" action="insert.php">
          <div class="row g-3">

            <div class="col-md-4">
            <label for="card_no" class="form-label">Card Number:</label>
            <input type="text" class="form-control" name="card_no" required>
            </div>
          
            <div class="col-md-4">
            <label for="name" class="form-label">Student Name:</label>
            <input type="text" class="form-control" name="name" required>
            </div>
            
            <div class="col-md-4">
            <label for="group_class" class="form-label">Group/Class:</label>
            <input type="text" class="form-control" name="group_class" required>
            </div>

            <div class="col-md-4">
            <label for="reg_no" class="form-label">Registration Number:</label>
            <input type="text" class="form-control" name="reg_no" required>
            </div>

            <div class="col-md-4">
            <label for="email" class="form-label">Email:</label>
            <input type="email" class="form-control" name="email" required>
            </div>

            <div class="col-md-4">
            <label for="phone" class="form-label">Phone:</label>
            <input type="text" class="form-control" name="phone" required>
            </div>

            <div class="col-md-4">
            <label for="address" class="form-label">Address:</label>
            <input type="text" class="form-control" name="address" required>
            </div>

          <div class="text-center mt-4">
            <button type="submit" name="register_student" class="btn btn-primary">
              <i class="bi bi-plus-lg"></i> Register Student
            </button>
          </div>
        </form>
      </div>
    </div>
  </main>

  <?php include "footer.php"; ?>

  <!-- Bootstrap JS -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
