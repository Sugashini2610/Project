<?php
include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

  <!-- Main CSS -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

  <style>
   .col-md-2 i{
      margin-right: 5px;
    }
  </style>

</head>

<body class="about-page">
<?php 
  include "nav.php";
?>

  <main class="main">
  <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
               </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">New Book Entry<br></li>
          </ol>
        </div>
      </nav>
    </div>
    <div class="container py-5">
      <div class="text-center mb-4">
        <h1 class="fw-bold">New Book Entry</h1>
      </div>
      <!-- <div class="row g-3">
            <div class="col-md-2" style="padding: 10px;">
              <label for="date" class="form-label">Date</label>
              <input type="date" class="form-control" name="date" required>
            </div>
     </div> -->
      <div class="card shadow p-4">
        <form method="post" action="insert.php">
          <div class="row g-3">
          
            <div class="col-md-2">
              <label for="s_no" class="form-label"><i class="bi bi-hash"></i> Accession No.</label>
              <?php
                $sql = "SELECT id FROM books ORDER BY id DESC";
                $sql_exe = mysqli_query($conn, $sql);

                if ($fetch_qr = mysqli_fetch_array($sql_exe)) {
                    $id = $fetch_qr['id'];
                    $id += 1;
                } else {
        // If no records found, start from 1
                    $id = '1001';
                }

                ?>
            <input type="text" class="form-control" name="id" id="id" value="<?php echo $id; ?>" readonly>
            </div>
            
            <div class="col-md-2">
              <label for="title" class="form-label"><i class="bi bi-book"></i> Title</label>
              <input type="text" class="form-control" name="title" required>
            </div>

            <div class="col-md-2">
              <label for="author" class="form-label"><i class="bi bi-person-fill"></i> Author</label>
              <input type="text" class="form-control" name="author" required>
            </div>

            <div class="col-md-2">
              <label for="subject" class="form-label"><i class="bi bi-journal-bookmark-fill"></i> Subject</label>
              <input type="text" class="form-control" name="subject" required>
            </div>

            <div class="col-md-2">
              <label for="edition" class="form-label"><i class="bi bi-layers"></i> Edition</label>
              <input type="text" class="form-control" name="edition" required>
            </div>

            <div class="col-md-2">
              <label for="volume" class="form-label"><i class="bi bi-collection"></i> Volume</label>
              <input type="text" class="form-control" name="volume" required>
            </div>

            <div class="col-md-2">
              <label for="topic" class="form-label"><i class="bi bi-lightbulb-fill"></i> Topic</label>
              <input type="text" class="form-control" name="received_by" required>
            </div>

            <div class="col-md-2">
              <label for="category" class="form-label"><i class="bi bi-tags-fill"></i> Category</label>
              <input type="text" class="form-control" name="category" required>
            </div>

            <div class="col-md-2">
              <label for="barcode_no" class="form-label"><i class="bi bi-upc-scan"></i> Barcode No.</label>
              <input type="text" class="form-control" name="barcode_no" required>
            </div>

            <div class="col-md-2">
              <label for="publisher" class="form-label"><i class="bi bi-building"></i> Publisher</label>
              <input type="text" class="form-control" name="publisher" required>
            </div>

            <div class="col-md-2">
              <label for="year" class="form-label"><i class="bi bi-calendar-event-fill"></i> Year</label>
              <input type="text" class="form-control" name="year" required>
            </div>

            <div class="col-md-2">
              <label for="location_rack" class="form-label"><i class="bi bi-geo-alt-fill"></i> Location/Rack</label>
              <input type="text" class="form-control" name="location_rack" required>
            </div>

            <div class="col-md-2">
              <label for="isbn" class="form-label"><i class="bi bi-bookmark-check-fill"></i> ISBN</label>
              <input type="text" class="form-control" name="isbn" required>
            </div>

            <div class="col-md-2">
              <label for="cost" class="form-label"><i class="bi bi-cash-coin"></i> Cost</label>
              <input type="text" class="form-control" name="cost" required>
            </div>
            
          </div>
          
          <div class="text-center mt-4">
            <button type="submit" name="add_book" class="btn btn-primary">
              <i class="bi bi-plus-lg"></i> Add Book
            </button>
          </div>
        </form>
      </div>
    </div>
  </main>

  <?php include "footer.php"; ?>

  <!-- Bootstrap JS -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
  window.onload = function() {
    document.querySelector('input[name="title"]').focus();
  };
</script>
</body>
</html>
