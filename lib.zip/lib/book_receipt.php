<?php 
include 'db.php';
$date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
$tdy_date = $date->format('d-m-Y ');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Mentor
  * Template URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->

  <style>
   .col-md-4 i{
      margin-right: 5px;
    }
  </style>
</head>

<body class="about-page">

<?php 
  include "nav.php";
?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
              <p class="mb-0">Odio et unde deleniti. Deserunt numquam exercitationem. Officiis quo odio sint voluptas consequatur ut a odio voluptatem. Sit dolorum debitis veritatis natus dolores. Quasi ratione sint. Sit quaerat ipsum dolorem.</p>
            </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Receipt<br></li>
          </ol>
        </div>
      </nav>
    </div><!-- End Page Title -->

    <div class="container py-5">
      <div class="text-center mb-4">
        <h1 class="fw-bold">Receipt</h1>
      </div>
      <!-- <div class="row g-3">
            <div class="col-md-2" style="padding: 10px;">
              <label for="date" class="form-label">Date</label>
              <input type="date" class="form-control" name="date" required>
            </div>
     </div> -->
      <div class="card shadow p-4">
        <form method="post" action="insert.php">
          <div class="row g-3">
          
            <div class="col-md-4">
                <label for="receipt_number" class="form-label"><i class="bi bi-receipt"></i>Receipt Number:</label>
                <?php
        $sql = "SELECT receipt_number FROM receipts ORDER BY receipt_number DESC";
        $sql_exe = mysqli_query($conn, $sql);

        if ($fetch_qr = mysqli_fetch_array($sql_exe)) {
           $idno = $fetch_qr['receipt_number'];
            // Extract the numeric part
            // Increment the numeric part
            $in_numeric = (int)$idno + 1;
            // Construct the new idno
            $bill_no  = '000' . $in_numeric;
        } else {
            // If no records found, start from 1
            $bill_no = '0001';
        }

    ?>
                <input type="text" class="form-control" name="receipt_number" value="<?php echo $bill_no; ?>" readonly><br>
            </div>
            
            <div class="col-md-4">
              <label for="s_no" class="form-label"><i class="bi bi-hash"></i>Accession No.</label>
              <input type="text" class="form-control" name="id" required><br>
            </div>

            <div class="col-md-4">
            <label for="student_card_no"><i class="bi bi-credit-card"></i>Student Card No.</label>
            <input type="text" class="form-control" name="card_no" id="card_no" required>
            </div>

            <div class="col-md-4">
            <label for="student_name"><i class="bi bi-person-fill"></i>Student Name</label>
            <input type="text" class="form-control" name="student_name" id="student_name" readonly>
            </div>

            <div class="col-md-4">
                <label for="payment_date" class="form-label"><i class="bi bi-calendar-event"></i>Date of Payment:</label>
                <input type="text" class="form-control" name="payment_date" value="<?php echo $tdy_date?>" required><br>
            </div>

            <div class="col-md-4">
                <label for="amount_paid" class="form-label"><i class="bi bi-currency-rupee"></i>Amount Paid:</label>
                <input type="number" class="form-control" name="amount_paid" required><br>
            </div>

            <div class="col-md-4">
            <label for="payment_method" class="form-label"><i class="bi bi-cash-coin"></i>Payment Method:</label>
            <input type="text" class="form-control" name="payment_method" required><br>
            </div>

            <div class="col-md-4">
            <label for="description" class="form-label"><i class="bi bi-journal"></i>Description:</label>
                <input type="text" class="form-control" name="description" required><br>
            </div>

            <div class="col-md-4">
                <label for="received_by" class="form-label"><i class="bi bi-person-badge-fill"></i>Received By:</label>
                <input type="text" class="form-control" name="received_by" required><br>
            </div>
          
          <div class="text-center mt-4">
            <button type="submit" name="record_payment" class="btn btn-primary">
              <i class=""></i> Submit
            </button>
          </div>
        </form>
      </div>
    </div>

  </main>

  <?php 
  include "footer.php";
  ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(document).ready(function() {
      // Fetch student name when card number is selected
      $("#card_no").change(function() {
        var card_no = $(this).val();
        $.ajax({
          url: "fetch_student.php",
          method: "POST",
          data: { card_no: card_no },
          dataType: "json",
          success: function(data) {
            $("#student_name").val(data.name);
          }
        });
      })
      });
  </script>
  <script>
  window.onload = function() {
    document.querySelector('input[name="id"]').focus();
  };
</script>

</body>

</html>