<?php
include 'db.php';

// Book count
$book_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM books"))['count'];
$student_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM students"))['count'];
$pending_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM purchase WHERE cost > amount_paid"))['count'];
$book_pending_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM book_issues WHERE issue_status='issued'"))['count'];

// Monthly Graph Data
$monthly_data = mysqli_query($conn, "SELECT date as month, SUM(cost) as total_cost, SUM(amount_paid) as total_paid FROM purchase GROUP BY month ORDER BY month ASC");

$months = [];
$total_costs = [];
$total_paids = [];
while ($row = mysqli_fetch_assoc($monthly_data)) {
    $months[] = $row['month'];
    $total_costs[] = $row['total_cost'];
    $total_paids[] = $row['total_paid'];
}

// Recent Transactions
$recent = mysqli_query($conn, "SELECT 'Purchase' AS type,name, date, cost, amount_paid  FROM purchase 
UNION ALL 
SELECT 'Receipt', student_name, payment_date AS date, amount_paid AS cost, amount_paid AS amount_paid FROM receipts 
UNION ALL 
SELECT 'Expense', name, date, amount AS cost, amount AS amount_paid FROM expense 
ORDER BY date DESC ");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Library Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    .card {
      border: none;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.08);
      transition: 0.3s;
    }
    .card:hover {
      transform: translateY(-5px);
    }
    .icon {
      font-size: 1.5rem;
    }
  </style>
</head>
<body class="bg-light">

<div class="container py-5">
  <!-- <h2 class="mb-4 text-center fw-bold">📘 Library Management Dashboard</h2> -->

  <!-- Summary Cards -->
  <div class="row g-4 mb-5 text-center">
    <div class="col-md-3">
      <div class="card p-4 bg-primary text-white">
        <h6><i class="bi bi-journal-bookmark icon me-2"></i>Total Books</h6>
        <h2><?= $book_count ?></h2>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 bg-success text-white">
        <h6><i class="bi bi-people icon me-2"></i>Total Students</h6>
        <h2><?= $student_count ?></h2>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 bg-warning text-dark">
        <h6><i class="bi bi-hourglass-split icon me-2"></i>Pending Books</h6>
        <h2><?= $book_pending_count ?></h2>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 bg-danger text-white">
        <h6><i class="bi bi-currency-rupee icon me-2"></i>Pending Purchases</h6>
        <h2><?= $pending_count ?></h2>
      </div>
    </div>
  </div>

  <!-- Chart -->
  <div class="card mb-5 p-4">
    <h5 class="mb-4">📊 Monthly Book Purchase vs Payment</h5>
    <canvas id="expenseChart" height="100"></canvas>
  </div>

  <!-- Recent Transactions Table -->
  <div class="card p-4">
    <h5 class="mb-3">🧾 Recent Transactions</h5>
    <div class="table-responsive">
      <table class="table table-hover table-bordered">
        <thead class="table-dark">
          <tr>
            <th>Type</th>
            <th>Name</th>
            <th>Date</th>
            <th>Amount</th>
            <th>Paid</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = mysqli_fetch_assoc($recent)) { ?>
          <tr>
            <td><?= $row['type'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['date'] ?></td>
            <td>₹<?= number_format($row['cost'], 2) ?></td>
            <td>₹<?= number_format($row['amount_paid'], 2) ?></td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('expenseChart').getContext('2d');
const expenseChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: <?= json_encode($months) ?>,
    datasets: [
      {
        label: 'Purchase',
        data: <?= json_encode($total_costs) ?>,
        backgroundColor: 'rgba(255, 99, 132, 0.7)'
      },
      {
        label: 'Payment',
        data: <?= json_encode($total_paids) ?>,
        backgroundColor: 'rgba(75, 192, 192, 0.7)'
      }
    ]
  },
  options: {
    responsive: true,
    scales: {
      y: { beginAtZero: true }
    }
  }
});
</script>

</body>
</html>
