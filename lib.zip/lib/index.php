<?php
include 'db.php';

// Book count
$book_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM books"))['count'];

$student_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM students"))['count'];

// Pending (unpaid purchases)
$pending_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM purchase WHERE cost > amount_paid"))['count'];

$book_pending_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM book_issues WHERE issue_status='issued'"))['count'];

// Expense over time (monthly)
$monthly_data = mysqli_query($conn, "SELECT DATE_FORMAT(date, '%Y-%m') as month, SUM(cost) as total_cost, SUM(amount_paid) as total_paid FROM purchase GROUP BY month ORDER BY month ASC");

$months = [];
$total_costs = [];
$total_paids = [];
while ($row = mysqli_fetch_assoc($monthly_data)) {
    $months[] = $row['month'];
    $total_costs[] = $row['total_cost'];
    $total_paids[] = $row['total_paid'];
}

// Recent Transactions
$recent = mysqli_query($conn, "SELECT 'Purchase' AS type,name, date, cost, amount_paid  FROM purchase UNION ALL SELECT 'Receipt', student_name, payment_date AS date, amount_paid AS cost, amount_paid AS amount_paid FROM receipts UNION ALL SELECT 'Expense', name, date, amount AS cost, amount AS amount_paid FROM expense ORDER BY date DESC ");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Index - Mentor Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">


  <!-- =======================================================
  * Template Name: Mentor
  * Template URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>
    h2,h6 {
      color: white;
    }
  </style>

</head>

<body class="index-page">

  <?php 
  include "nav.php";
  ?>

  <main class="main">
  
  <div class="container py-5">
  <!-- <h2 class="mb-4 text-center fw-bold">📘 Library Management Dashboard</h2> -->

  <!-- Summary Cards -->
  <div class="row g-4 mb-5 text-center">
    <div class="col-md-3">
      <div class="card p-4 bg-primary text-white" style=" border: none;border-radius: 15px;box-shadow: 0 4px 10px rgba(0,0,0,0.08); transition: 0.3s; ">
        <h6 style=" font-size: 1.5rem;"><i class="bi bi-journal-bookmark icon me-2" style=" font-size: 2rem; color: white;"></i>Total Books</h6>
        <h2><?= $book_count ?></h2>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 bg-success text-white"  style=" border: none;border-radius: 15px;box-shadow: 0 4px 10px rgba(0,0,0,0.08); transition: 0.3s; ">
        <h6 style=" font-size: 1.5rem;"><i class="bi bi-people icon me-2" style=" font-size: 2rem; color: white;"></i>Total Students</h6>
        <h2><?= $student_count ?></h2>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 bg-warning text-dark"  style=" border: none;border-radius: 15px;box-shadow: 0 4px 10px rgba(0,0,0,0.08); transition: 0.3s; ">
        <h6 style=" font-size: 1.5rem;"><i class="bi bi-hourglass-split icon me-2" style=" font-size: 2rem; color: white;"></i>Pending Books</h6>
        <h2><?= $book_pending_count ?></h2>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 bg-danger text-white"  style=" border: none;border-radius: 15px;box-shadow: 0 4px 10px rgba(0,0,0,0.08); transition: 0.3s; ">
        <h6 style=" font-size: 1.5rem;"><i class="bi bi-currency-rupee icon me-2" style=" font-size: 2rem; color: white;"></i>Pending Purchases</h6>
        <h2><?= $pending_count ?></h2>
      </div>
    </div>
  </div>

  <!-- Chart -->
  <div class="card mb-5 p-4">
    <h5 class="mb-4">📊 Monthly Book Purchase vs Payment</h5>
    <canvas id="expenseChart" height="100"></canvas>
  </div>

  <!-- Recent Transactions Table -->
  <div class="card p-4">
    <h5 class="mb-3">🧾 Recent Transactions</h5>
    <div class="table-responsive">
      <table class="table table-hover table-bordered">
        <thead class="table-dark">
          <tr>
            <th>Type</th>
            <th>Name</th>
            <th>Date</th>
            <th>Amount</th>
            <th>Paid</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = mysqli_fetch_assoc($recent)) { ?>
          <tr>
            <td><?= $row['type'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['date'] ?></td>
            <td>₹<?= number_format($row['cost'], 2) ?></td>
            <td>₹<?= number_format($row['amount_paid'], 2) ?></td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('expenseChart').getContext('2d');
const expenseChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: <?= json_encode($months) ?>,
    datasets: [
      {
        label: 'Total Cost',
        data: <?= json_encode($total_costs) ?>,
        backgroundColor: 'rgba(255, 99, 132, 0.7)'
      },
      {
        label: 'Amount Paid',
        data: <?= json_encode($total_paids) ?>,
        backgroundColor: 'rgba(75, 192, 192, 0.7)'
      }
    ]
  },
  options: {
    responsive: true,
    scales: {
      y: { beginAtZero: true }
    }
  }
});
</script>

  </main>

  <?php 
  include "footer.php";
  ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

    <!-- jQuery (Required for DataTables) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script>
	$(document).ready(function() {
	$('#daybook-table').DataTable({
            "pageLength": 10,  // Show 5 entries per page
            "lengthMenu": [ 10, 25, 50, 100],  // Options for entries per page
			      "searching": false,  // Disable search
            "ordering": false,  // Disable sorting
            "info": false 
        });
});
</script>
</body>
</html>