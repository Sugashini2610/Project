<?php
include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">


  <!-- Main CSS -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">

</head>

<body class="about-page">
  
<?php 
  include "nav.php";
 ?>

  <main class="main">
  <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
               </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Voucher<br></li>
          </ol>
        </div>
      </nav>
    </div>
      <div class="container py-5">
      <div class="text-center mb-4">
        <h2 class="fw-bold">Voucher</h2>
      </div>
      </div>
      <div class="table-container" style="padding: 10px;">
          
    <table id="daybook-table" class="table table-bordered table-striped">
    <thead class="table-dark text-center">
            <tr>
              <th>S.No</th>
              <th>Name</th>
              <!-- <th>Bill No</th> -->
              <th>Date</th>
              <th>Cost</th>
              <th>Amount Paid</th>
              <th>Balance</th>
              <th>View</th>
              <th>Pay</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $sql = "SELECT name, bill_no, date, SUM(cost) AS total_cost,SUM(amount_paid) AS total_paid FROM purchase GROUP BY bill_no, date, name ORDER BY date DESC ";

            $result = mysqli_query($conn, $sql);
            $sno = 1;

            if ($result && mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                $balance = floatval($row['total_cost']) - floatval($row['total_paid']);
                ?>
                <tr class="text-center">
                  <td><?php echo $sno++; ?></td>
                  <td><?php echo htmlspecialchars($row['name']); ?></td>
                  <!-- <td><?php echo htmlspecialchars($row['bill_no']); ?></td> -->
                  <td><?php echo htmlspecialchars($row['date']); ?></td>
                  <td><?php echo number_format($row['total_cost'], 2); ?></td>
                  <td><?php echo number_format($row['total_paid'], 2); ?></td>
                  <td><?php echo number_format($balance, 2); ?></td>
                  <td>
                    <a href="view_purchase.php?bill_no=<?php echo urlencode($row['bill_no']); ?>" class="btn btn-outline-info btn-sm" title="View">
                      <i class="bi bi-eye-fill"></i>
                    </a>
                  </td>
                  <td>
                    <?php
                      if ($balance == 0) {
                        echo '<button class="btn btn-success btn-sm" disabled>Paid</button>';
                      } elseif ($balance == $row['total_cost']) {
                        echo '<a href="pay_purchase.php?bill_no=' . urlencode($row['bill_no']) . '" class="btn btn-danger btn-sm">Not Paid</a>';
                      } else {
                        echo '<a href="pay_purchase.php?bill_no=' . urlencode($row['bill_no']) . '" class="btn btn-warning btn-sm text-dark">Pending</a>';
                      }
                    ?>
                  </td>
                </tr>
                <?php
              }
            } else {
              echo '<tr><td colspan="9" class="text-center">No records found.</td></tr>';
            }
            ?>
          </tbody>
    </table>
    </div>
      </div>
    </div>
  </main>

  <?php include "footer.php"; ?>

  <!-- Bootstrap JS -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- jQuery (Required for DataTables) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>

<script>
	$(document).ready(function() {
	$('#daybook-table').DataTable({
            "pageLength": 10,  // Show 5 entries per page
            "lengthMenu": [ 10, 25, 50, 100],  // Options for entries per page
			      "searching": false,  // Disable search
            "ordering": false,  // Disable sorting
            "info": false 
        });
});
</script>

</body>
</html>

