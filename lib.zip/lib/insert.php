<?php
// Database connection details
$servername = "localhost"; // Replace with your server name
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "library_management"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Organization Registration Page
if (isset($_POST['register_organization'])) {
    $company_name = $_POST['company_name'];
    $address = $_POST['address'];
    $phone_number = $_POST['phone_number'];

    $sql = "INSERT INTO organizations (company_name, address, phone_number) VALUES ('$company_name', '$address', '$phone_number')";

    if ($conn->query($sql) === TRUE) {
        echo "Organization registered successfully!";
        // Redirect to login page
        header("Location: login.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Login Page
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);

    if (mysqli_num_rows($result) > 0) {
        // Start session
        session_start();
        $_SESSION['username'] = $username;
        echo "Logged in successfully!";
        // Redirect to a main page
        header("Location: index.php");
        exit();
    } else {
        echo "Invalid username or password.";
    }
}

// New Book Entry Page
if (isset($_POST['add_book'])) {
    $s_no = $_POST['id'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $subject = $_POST['subject'];
    $edition = $_POST['edition'];
    $volume = $_POST['volume'];
    $topic = $_POST['topic'];
    $category = $_POST['category'];
    $barcode_no = $_POST['barcode_no'];
    $publisher = $_POST['publisher'];
    $year = $_POST['year'];
    $location_rack = $_POST['location_rack'];
    $isbn = $_POST['isbn'];
    $cost = $_POST['cost'];

    $sql = "INSERT INTO books (id, title, author, subject, edition, volume, topic, category, barcode_no, publisher, year, location_rack, isbn, cost)
            VALUES ('$s_no', '$title', '$author', '$subject', '$edition', '$volume', '$topic', '$category', '$barcode_no', '$publisher', '$year', '$location_rack', '$isbn', '$cost')";

    if ($conn->query($sql) === TRUE) {
        echo "New book added successfully!";
        header("Location: book_list.php"); //stay in book list
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Book List Page
function getBookList($conn) {
    $sql = "SELECT * FROM books";
    $result = $conn->query($sql);

    $books = array();
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $books[] = $row;
        }
    }
    return $books;
}

// Book Issue Page
if (isset($_POST['issue_book'])) {
    $student_name = $_POST['student_name'];
    $student_id = $_POST['student_id'];
    $id = $_POST['id'];
    $book_title = $_POST['book_title'];
    $book_barcode = $_POST['book_barcode'];
    $issue_date = $_POST['issue_date'];
    $due_date = $_POST['due_date'];
    $issued_by = $_POST['issued_by'];
    $issue_status = "Issued"; // Set default status

     //update book table to reduce available copies
    // $sql_update_book = "UPDATE books SET available_copies = available_copies - 1 WHERE barcode_no = '$book_barcode'";
    // if ($conn->query($sql_update_book) !== TRUE) {
    //     echo "Error updating book copies: " . $conn->error;
    // }
    
    $sql = "INSERT INTO book_issues (student_id, student_name, id, book_title, book_barcode, issue_date, due_date, issued_by, issue_status)
            VALUES ( '$student_id', '$student_name', '$id','$book_title', '$book_barcode', '$issue_date', '$due_date', '$issued_by', '$issue_status')";

    if ($conn->query($sql) === TRUE) {
        echo "Book issued successfully!";
         header("Location: issue_list.php");
         exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Issued List Page
function getIssuedList($conn) {
    $sql = "SELECT * FROM book_issues";
    $result = $conn->query($sql);

    $issues = array();
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $issues[] = $row;
        }
    }
    return $issues;
}
//Receipt Book page
if (isset($_POST['record_payment'])) {
    $receipt_number = $_POST['receipt_number'];
    $id = $_POST['id'];
    $card_no = $_POST['card_no'];
    $student_name = $_POST['student_name'];
    $payment_date = $_POST['payment_date'];
    $amount_paid = $_POST['amount_paid'];
    $payment_method = $_POST['payment_method'];
    $description = $_POST['description'];
    $received_by = $_POST['received_by'];

    $sql = "INSERT INTO receipts (receipt_number, id, card_no, student_name, payment_date, amount_paid, payment_method, description, received_by)
            VALUES ('$receipt_number', '$id', '$card_no', '$student_name', '$payment_date', '$amount_paid', '$payment_method', '$description', '$received_by')";

    if ($conn->query($sql) === TRUE) {
        $update_sql = "UPDATE book_issues SET return_date = '$payment_date', issue_status = 'returned' WHERE id = '$id' AND student_id = '$card_no' AND issue_status = 'issued'";

        if ($conn->query($update_sql) === TRUE) {
            echo "Payment recorded successfully!";
            header("Location: ledger.php?student_name=$student_name");
            exit();
        } else {
            echo "Error updating book issue record: " . $conn->error;
        }
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Student Registration Page
if (isset($_POST['register_student'])) {
    $name = $_POST['name'];
    $group_class = $_POST['group_class'];
    $reg_no = $_POST['reg_no'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $card_no = $_POST['card_no'];
    $address = $_POST['address'];

    $sql = "INSERT INTO students (name, group_class, reg_no, email, phone, card_no,address)
            VALUES ('$name', '$group_class', '$reg_no', '$email', '$phone', '$card_no','$address')";

    if ($conn->query($sql) === TRUE) {
        echo "Student registered successfully!";
         header("Location: index.php"); //register success
         exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

if (isset($_POST['expense'])) {
    $name = $_POST['name'];
    $category= $_POST['category'];
    $amount = $_POST['amount'];
    $pay_type = $_POST['pay_type'];
    $remark = $_POST['remark'];
    $date = $_POST['date'];
    
    $sql = "INSERT INTO expense( name, category, amount, pay_type, remark, date) VALUES ( '$name', '$category','$amount', '$pay_type', '$remark', '$date')";

    if ($conn->query($sql) === TRUE) {
        echo "Expense inserted successfully!";
         header("Location: expense.php");
         exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

//Ledger Page
function getLedgerEntries($conn, $student_name) {
    $sql = "SELECT * FROM receipts WHERE student_name = '$student_name'";
    $result = $conn->query($sql);

    $ledgerEntries = array();
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $ledgerEntries[] = $row;
        }
    }
    return $ledgerEntries;
}

function calculateBalance($ledgerEntries) {
    $total = 0;
    foreach ($ledgerEntries as $entry) {
        $total += $entry['amount_paid'];
    }
    return $total;
}
// Pending Book List Page -  books that are overdue
function getPendingBooks($conn) {
    $sql = "SELECT * FROM book_issues WHERE issue_status = 'Issued' AND due_date < CURDATE()";
    $result = $conn->query($sql);

    $pendingBooks = array();
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $pendingBooks[] = $row;
        }
    }
    return $pendingBooks;
}


?>
