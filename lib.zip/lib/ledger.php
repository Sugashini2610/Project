<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

  <!-- Main CSS -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body class="about-page">
<?php
  include "nav.php"; 
?>

  <main class="main">
  <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
               </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Ledger<br></li>
          </ol>
        </div>
      </nav>
    </div>
    <div class="container py-5">
      <div class="text-center mb-4">
        <h1 class="fw-bold">Ledger</h1>
      </div>
      <!-- <div class="row g-3">
            <div class="col-md-2" style="padding: 10px;">
              <label for="date" class="form-label">Date</label>
              <input type="date" class="form-control" name="date" required>
            </div>
     </div> -->
      <div class="card shadow p-4">
        <!-- <form method="post" action="insert.php">
          <div class="row g-3">

            <div class="col-md-6">
            <label for="student_name" class="form-label">Select Student:</label>
            <input type="text" class="form-control" name="student_name" required>
            </div>
          
            
          <div class="col-md-6">
            <p  style="padding:8px;"></p>
            <button type="submit" name="ledger" class="btn btn-primary">
              <i class="bi"></i> Show Ledger
            </button>
          </div>
        </form> -->
        <?php
        if (isset($_GET['student_name'])) {
            $student_name = $_GET['student_name'];
            include 'insert.php';  // Include PHP file to get ledger entries
            $ledgerEntries = getLedgerEntries($conn, $student_name);
            $total = calculateBalance($ledgerEntries);
            echo "<h5>Ledger for " . $student_name . "</h5>";
            echo "<div class='card shadow p-4'>
          <table class='table table-bordered table-striped'>
                    <thead class='table-dark'>
                        <tr>
                        
                            <th>Receipt No.</th>
                            <th>Student Name:</th>
                            <th>Date of Payment:</th>
                            <th>Amount Paid</th>
                            <th>Payment Method</th>
                            <th>Description</th>
                            <th>Received By</th>
                            
                        </tr>
                    </thead>
                    <tbody>";
            foreach ($ledgerEntries as $entry) {
                echo "<tr>";
                echo "<td>" . $entry['receipt_number'] . "</td>";
                echo "<td>" . $entry['student_name'] . "</td>";
                echo "<td>" . $entry['payment_date'] . "</td>";
                echo "<td>" . $entry['amount_paid'] . "</td>";
                echo "<td>" . $entry['payment_method'] . "</td>";
                echo "<td>" . $entry['description'] . "</td>";
                echo "<td>" . $entry['received_by'] . "</td>";
                echo "</tr>";
            }
            echo "</tbody>
                </table>
                </div>";
            echo "<p><strong>Total:</strong> " . $total . "</p>";
        }
        ?>
      </div>
    </div>
  </main>

  <?php include "footer.php"; ?>

  <!-- Bootstrap JS -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
