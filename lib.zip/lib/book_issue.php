<?php 
include "db.php"; // Include database connection
$date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
$tdy_date = $date->format('d-m-Y ');
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Mentor
  * Template URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>
   .col-md-4 i{
      margin-right: 5px;
    }
  </style>
</head>

<body class="about-page">

<?php 
  include "nav.php";
?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
              <p class="mb-0">Odio et unde deleniti. Deserunt numquam exercitationem. Officiis quo odio sint voluptas consequatur ut a odio voluptatem. Sit dolorum debitis veritatis natus dolores. Quasi ratione sint. Sit quaerat ipsum dolorem.</p>
            </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Book Issue<br></li>
          </ol>
        </div>
      </nav>
    </div><!-- End Page Title -->
    <div class="container py-5">
      <div class="text-center mb-4">
        <h1 class="fw-bold">Book Issue</h1>
      </div>
     
      <div class="card shadow p-4">
        <form method="post" action="insert.php">
          <div class="row g-3">
            
            <div class="col-md-4">
            <label for="student_card_no"><i class="bi bi-credit-card-2-front-fill"></i> Student Card No.</label>
            <select class="form-control" name="student_id" id="student_id" required>
                <option value="">Select Student Card No.</option>
                <?php
                  $students = mysqli_query($conn, "SELECT card_no, name FROM students");
                  while ($row = mysqli_fetch_assoc($students)) {
                    echo "<option value='" . $row['card_no'] . "'>" . $row['card_no'] . "</option>";
                  }
                ?>
              </select>
            </div>

            <div class="col-md-4">
            <label for="student_name"><i class="bi bi-person-circle"></i> Student Name</label>
            <input type="text" class="form-control" name="student_name" id="student_name" readonly>
            </div>

             <div class="col-md-4">
            <label for="student_name"><i class="bi bi-hash"></i> Accession No.</label>
            <select class="form-control" name="id" id="id" required>
                <option value="">Select Accession No.</option>
                <?php
                  $books = mysqli_query($conn, "SELECT id, title, barcode_no FROM books");
                  
                  while ($row = mysqli_fetch_assoc($books)) {
                    echo "<option value='" . $row['id'] . "'>" . $row['id'] . "</option>";
                  }
                ?>
              </select>
            </div>

            <div class="col-md-4">
            <label for="book_title"><i class="bi bi-book"></i> Book Title</label>
            <input type="text" class="form-control" name="book_title" id="book_title" readonly>
            </div>

            <div class="col-md-4">
            <label for="book_barcode"><i class="bi bi-upc-scan"></i> Book Barcode</label>
            <input type="text" class="form-control" name="book_barcode" id="book_barcode" readonly>
            </div>

            <div class="col-md-4">
            <label for="issue_date"><i class="bi bi-calendar-date"></i> Issue Date</label>
            <input type="text" class="form-control" name="issue_date" id="issue_date" value="<?php echo $tdy_date?>"readonly>
            </div>

            <div class="col-md-4">
            <label for="due_date"><i class="bi bi-calendar-event"></i> Due Date</label>
            <input type="date"  class="form-control" name="due_date" required><br>
             </div>

            <div class="col-md-4">
            <label for="issued_by"><i class="bi bi-person-badge-fill"></i> Issued By</label>
            <input type="text"  class="form-control" name="issued_by" required><br>
            </div>
            
             <div class="text-center mt-4">
            <button type="submit" name="issue_book" class="btn btn-primary">
            <i class="bi bi-plus-lg"></i> Issue Book
            </button>
          </div>
                </div>

              </div>
            </form>
            
          </div><!-- End Contact Form -->

        </form>
      </div>
      

    </section><!-- /About Us Section -->


  </main>

  <?php 
  include "footer.php";
  ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(document).ready(function() {
      // Fetch student name when card number is selected
      $("#student_id").change(function() {
        var student_id = $(this).val();
        $.ajax({
          url: "fetch_student.php",
          method: "POST",
          data: { student_id: student_id },
          dataType: "json",
          success: function(data) {
            $("#student_name").val(data.name);
          }
        });
      });

      // Fetch book details when accession number is selected
      $("#id").change(function() {
        var id = $(this).val();
        $.ajax({
          url: "fetch_book.php",
          method: "POST",
          data: { id: id },
          dataType: "json",
          success: function(data) {
            $("#book_title").val(data.title);
            $("#book_barcode").val(data.barcode_no);
          }
        });
      });
    });
  </script>
  <script>
  window.onload = function() {
    document.querySelector('select[name="student_id"]').focus();
  };
</script>


</body>

</html>