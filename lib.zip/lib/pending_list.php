<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

  <!-- Main CSS -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">

</head>

<body class="about-page">
  
<?php 
  include "nav.php";
?>
  <main class="main">
  <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
               </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Pending List<br></li>
          </ol>
        </div>
      </nav>
    </div>
      <div class="container py-5">
      <div class="text-center mb-4">
        <h2 class="fw-bold">Pending List</h2>
      </div>
        <div class="card shadow p-4">
          <table id="daybook-table" class="table table-bordered table-striped">
            <thead class="table-dark">
            <tr>
                    <th>Student Name</th>
                    <th>Book Title</th>
                    <th>Issue Date</th>
                    <th>Due Date</th>
                    <th>Days Overdue</th>
                    <th>Fine Amount Due</th>
                </tr>
            </thead>
            <tbody>
             <?php
                include 'insert.php';  // Include PHP file to get pending books
                $pendingBooks = getPendingBooks($conn);

if (!$pendingBooks || count($pendingBooks) == 0) {
    echo "<tr><td colspan='6' class='text-center'>No overdue books found.</td></tr>";
    exit;  // Stop execution if no books are found
} else {
    echo "<script>console.log('Pending Books Found: " . count($pendingBooks) . "');</script>";

                foreach ($pendingBooks as $book) {
                    $due_date = strtotime($book['due_date']);
                    $today = strtotime(date("Y-m-d"));
                    $days_overdue = max(0, ($today - $due_date) / (60 * 60 * 24));
                    $fine_amount = $days_overdue * 10; // Example: $10 fine per day
                    echo "<tr>";
                    echo "<td>" . $book['student_name'] . "</td>";
                    echo "<td>" . $book['book_title'] . "</td>";
                    echo "<td>" . $book['issue_date'] . "</td>";
                    echo "<td>" . $book['due_date'] . "</td>";
                    echo "<td>" . $days_overdue . "</td>";
                    echo "<td>$" . $fine_amount . "</td>";
                    echo "</tr>";
                }
}
                ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>

  <?php include "footer.php"; ?>

  <!-- Bootstrap JS -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery (Required for DataTables) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>

<script>
	$(document).ready(function() {
	$('#daybook-table').DataTable({
            "pageLength": 10,  // Show 5 entries per page
            "lengthMenu": [ 10, 25, 50, 100],  // Options for entries per page
			      "searching": false,  // Disable search
            "ordering": false,  // Disable sorting
            "info": false 
        });
});
</script>

</body>
</html>
