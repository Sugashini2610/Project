<?php
include "db.php";
if(isset($_POST["student_id"])) {
  $student_id = $_POST["student_id"];
  $query = "SELECT name FROM students WHERE card_no = '$student_id'";
  $result = mysqli_query($conn, $query);
  $row = mysqli_fetch_assoc($result);
  echo json_encode($row);
}

if(isset($_POST["card_no"])) {
  $student_id = $_POST["card_no"];
  $query = "SELECT name FROM students WHERE card_no = '$student_id'";
  $result = mysqli_query($conn, $query);
  $row = mysqli_fetch_assoc($result);
  echo json_encode($row);
}
?>
