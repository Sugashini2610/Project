<?php
include 'db.php';


if (!isset($_GET['bill_no'])) {
  echo "Invalid Request!";
  exit;
}

$bill_no = mysqli_real_escape_string($conn, $_GET['bill_no']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $amount = floatval($_POST['amount']);

  $sql = "UPDATE purchase SET amount_paid = amount_paid + $amount WHERE bill_no = ?";
  $stmt = mysqli_prepare($conn, $sql);
  mysqli_stmt_bind_param($stmt, "s", $bill_no);
  mysqli_stmt_execute($stmt);
  mysqli_stmt_close($stmt);

  header("Location: voucher.php");
  exit;
}

$sql = "SELECT p.name, p.date, p.bill_no, SUM(p.cost) AS total_cost, SUM(p.amount_paid) AS total_paid,b.title FROM purchase p LEFT JOIN books b ON p.book_id = b.id WHERE p.bill_no = '$bill_no'GROUP BY p.bill_no";
$result = mysqli_query($conn, $sql);
$data = mysqli_fetch_assoc($result);
$balance = floatval($data['total_cost']) - floatval($data['total_paid']);
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

  <!-- Main CSS -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body class="about-page">
  
<?php 
  include "nav.php";
 ?>
  <main class="main">
  <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
               </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Payment<br></li>
          </ol>
        </div>
      </nav>
    </div>
    <div class="container py-5">
      <div class="text-center mb-4">
        <h1 class="fw-bold">Make Payment</h1>
      </div>
      <!-- <div class="row g-3">
            <div class="col-md-2" style="padding: 10px;">
              <label for="date" class="form-label">Date</label>
              <input type="date" class="form-control" name="date" required>
            </div>
     </div> -->
      <div class="card shadow p-4">
      <?php if ($balance > 0): ?>
        <form method="post">
          <div class="row g-3">
          
          <div class="col-md-2">
            <label for="bill_no" class="form-label">Bill No.</label>
            <input type="text" class="form-control" name="bill_no" id="bill_no" value="<?php echo $data['bill_no']; ?>" readonly>
          </div>
          <div class="col-md-2">
            <label for="issue_date"> Date</label>
            <input type="text" class="form-control" name="date" id="date" value="<?php echo $data['date']; ?>" readonly>
         </div>
          <div class="col-md-2">
            <label for="tot_cost" class="form-label">Total Cost:</label>
            <input type="text" class="form-control" style="background-color: #fff3cd;" name="total_cost" id="total_cost" value="<?= number_format($data['total_cost'], 2) ?>" readonly>
          </div>
          <div class="col-md-2">
            <label for="bill_no" class="form-label">Total Paid:</label>
            <input type="text" class="form-control" style="background-color: #d4edda;" name="total_paid" id="total_paid" value="<?= number_format($data['total_paid'], 2) ?>"  readonly>
          </div>
          <div class="col-md-2">
            <label for="bill_no" class="form-label">Balance:</label>
            <input type="text" class="form-control" style="background-color: #f8d7da;" name="balance" id="balance" value=" ₹<?= number_format($balance, 2) ?>" readonly>
          </div>
          <div class="col-md-2">
            <label for="amount" class="form-label">Amount to Pay</label>
            <input type="text" name="amount" class="form-control" required max="<?= $balance ?>">
          </div>
        </div>

          
          <div class="text-center mt-4">
          <button type="submit" class="btn btn-primary">Submit Payment</button>
          </div>
        </form>
        <?php else: ?>
    <div class="alert alert-success">Payment already completed.</div>
  <?php endif; ?>
      </div>
    </div>
  </main>

  <?php include "footer.php"; ?>

  <!-- Bootstrap JS -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script>
  window.onload = function() {
    document.querySelector('input[name="amount"]').focus();
  };
</script>
</body>
</html>
