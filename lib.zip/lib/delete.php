<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $sql = "DELETE FROM books WHERE id = '$id'";
    if (mysqli_query($conn, $sql)) {
        echo "Deleted successfully";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
