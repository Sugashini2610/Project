<?php
include 'db.php';

// Get ID from URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the book from the database
    $sql = "SELECT * FROM books WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $book = mysqli_fetch_assoc($result);
    } else {
        echo "Book not found!";
        exit;
    }
} else {
    echo "Invalid request!";
    exit;
}

// If form is submitted, update the book
if (isset($_POST['update'])) {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $subject = $_POST['subject'];
    $edition = $_POST['edition'];
    $volume = $_POST['volume'];
    $topic = $_POST['topic'];
    $category = $_POST['category'];
    $barcode_no = $_POST['barcode_no'];
    $publisher = $_POST['publisher'];
    $year = $_POST['year'];
    $location_rack = $_POST['location_rack'];
    $isbn = $_POST['isbn'];
    $cost = $_POST['cost'];

    $update_query = "UPDATE books SET 
        title='$title', 
        author='$author', 
        subject='$subject',
        edition='$edition',
        volume='$volume',
        topic='$topic',
        category='$category',
        barcode_no='$barcode_no',
        publisher='$publisher',
        year='$year',
        location_rack='$location_rack',
        isbn='$isbn',
        cost='$cost' 
        WHERE id='$id'";

    if (mysqli_query($conn, $update_query)) {
        header("Location: book_list.php?updated=1");
        exit;
    } else {
        echo "Error updating book: " . mysqli_error($conn);
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

  <!-- Main CSS -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body class="about-page">
  
  <?php include "nav.php"; ?>

  <main class="main">
  <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
               </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Edit Book Entry<br></li>
          </ol>
        </div>
      </nav>
    </div>
    <div class="container py-5">
      <div class="text-center mb-4">
        <h1 class="fw-bold">Edit Book Entry</h1>
      </div>
      <!-- <div class="row g-3">
            <div class="col-md-2" style="padding: 10px;">
              <label for="date" class="form-label">Date</label>
              <input type="date" class="form-control" name="date" required>
            </div>
     </div> -->
      <div class="card shadow p-4">
        <form method="post">
          <div class="row g-3">
          
          <div class="col-md-2">
                <label>Title</label>
                <input type="text" name="title" value="<?= $book['title'] ?>" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label>Author</label>
                <input type="text" name="author" value="<?= $book['author'] ?>" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label>Subject</label>
                <input type="text" name="subject" value="<?= $book['subject'] ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label>Edition</label>
                <input type="text" name="edition" value="<?= $book['edition'] ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label>Volume</label>
                <input type="text" name="volume" value="<?= $book['volume'] ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label>Topic</label>
                <input type="text" name="topic" value="<?= $book['topic'] ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label>Category</label>
                <input type="text" name="category" value="<?= $book['category'] ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label>Barcode No</label>
                <input type="text" name="barcode_no" value="<?= $book['barcode_no'] ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label>Publisher</label>
                <input type="text" name="publisher" value="<?= $book['publisher'] ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label>Year</label>
                <input type="text" name="year" value="<?= $book['year'] ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label>Location/Rack</label>
                <input type="text" name="location_rack" value="<?= $book['location_rack'] ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label>ISBN</label>
                <input type="text" name="isbn" value="<?= $book['isbn'] ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label>Cost</label>
                <input type="text" name="cost" value="<?= $book['cost'] ?>" class="form-control">
            </div>
        </div>

          
          <div class="text-center mt-4">
          <button type="submit" name="update" class="btn btn-success">Update</button>
          <a href="book_list.php" class="btn btn-secondary">Cancel</a>
          </div>
        </form>
      </div>
    </div>
  </main>

  <?php include "footer.php"; ?>

  <!-- Bootstrap JS -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
