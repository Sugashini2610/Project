<?php
include 'db.php';

if (!isset($_GET['bill_no'])) {
    echo "Invalid Request!";
    exit;
}

$bill_no = mysqli_real_escape_string($conn, $_GET['bill_no']);

// Fetch purchase details by bill_no
$sql = "SELECT p.book_id, p.name, p.date, p.cost, p.amount_paid, b.title, b.author, b.category, b.publisher 
        FROM purchase p
        JOIN books b ON p.book_id = b.id
        WHERE p.bill_no = '$bill_no'";

$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "No purchase found for this bill number!";
    exit;
}

$total_cost = 0;
$total_paid = 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Library Management System</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">


  <!-- Main CSS -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

  
</head>

<body class="about-page">
  
<?php 
  include "nav.php";
 ?>

  <main class="main">
  <div class="page-title" data-aos="fade">
      <!-- <div class="heading">
        <div class="container">
          <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              <h1>About Us<br></h1>
               </div>
          </div>
        </div>
      </div> -->
      <nav class="breadcrumbs">
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Voucher<br></li>
          </ol>
        </div>
      </nav>
    </div>
      <div class="container py-5">
      <div class="text-center mb-4">
        <h2 class="fw-bold">Voucher</h2>
      </div>
      </div>
      <div class="table-container" style="padding: 10px;">
      <table class="table table-bordered table-striped">
        <thead class="table-dark text-center">
          <tr>
            <th>S.No</th>
            <th>Book ID</th>
            <th>Book Title</th>
            <th>Author</th>
            <th>Category</th>
            <th>Publisher</th>
            <th>Cost (₹)</th>
            <th>Paid (₹)</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $sno = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            $total_cost += $row['cost'];
            $total_paid += $row['amount_paid'];
            ?>
            <tr class="text-center">
              <td><?php echo $sno++; ?></td>
              <td><?php echo $row['book_id']; ?></td>
              <td><?php echo $row['title']; ?></td>
              <td><?php echo $row['author']; ?></td>
              <td><?php echo $row['category']; ?></td>
              <td><?php echo $row['publisher']; ?></td>
              <td><?php echo number_format($row['cost'], 2); ?></td>
              <td><?php echo number_format($row['amount_paid'], 2); ?></td>
            </tr>
        <?php } ?>
        </tbody>
        <tfoot>
          <tr class="fw-bold text-center">
            <td colspan="6">Total</td>
            <td>₹<?php echo number_format($total_cost, 2); ?></td>
            <td>₹<?php echo number_format($total_paid, 2); ?></td>
          </tr>
          <tr class="fw-bold text-center">
            <td colspan="6">Balance</td>
            <td colspan="2">₹<?php echo number_format($total_cost - $total_paid, 2); ?></td>
          </tr>
        </tfoot>
      </table>

      <div class="text-center mt-3">
        <a href="voucher.php" class="btn btn-secondary">
          <i class="bi bi-arrow-left-circle"></i> Back
        </a>
      </div>
    </div>
    </div>
  </main>

  <?php include "footer.php"; ?>

  <!-- Bootstrap JS -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>


