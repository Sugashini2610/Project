
<style>
    .icon-container:hover {
      transform: translateY(-5px);
    }
    .icon {
      font-size: 15px;
      color:black;
    }
  </style>
  <header id="header" class="header d-flex align-items-center sticky-top">
  <div class="container-fluid container-xl position-relative d-flex align-items-center">

    <a href="index.php" class="logo d-flex align-items-center me-auto">
      <!-- Uncomment the line below if you also wish to use an image logo -->
      <!-- <img src="assets/img/logo.png" alt=""> -->
      <h1 class="sitename">Mentor</h1>
    </a>

    <nav id="navmenu" class="navmenu">
      <ul>
        <li><a href="index.php"><i class="bi bi-house-door nav-icons"></i>Home</a></li>
        <li><a href="new_book_entry.php"><i class="bi bi-plus-circle nav-icons"></i>New Book Entry</a></li>
        <li><a href="book_list.php"><i class="bi bi-journal-text nav-icons"></i>Book List</a></li>
        <li><a href="book_issue.php"><i class="bi bi-box-arrow-in-right nav-icons"></i>Book Issue</a></li>
        <li><a href="issue_list.php"><i class="bi bi-receipt nav-icons"></i>Issue List</a></li>
        <li><a href="book_receipt.php"><i class="bi bi-bookmark-check nav-icons"></i>Book Receipt</a></li>
        <li class="dropdown"><a href="#"><i class="bi bi-cart nav-icons"></i><span>Purchase</span><i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="new_book_entry.php">Existing Book</a></li>
              <li><a href="pub_purchase.php">Publisher Purchase</a></li>
              <li><a href="stud_purchase.php">Student Purchase</a></li>
              <li><a href="voucher.php">Voucher</a></li>
            </ul>
          </li>
        <!-- <li><a href="ledger.php"><i class="bi bi-clipboard-data nav-icons"></i>Ledger</a></li> -->
        <li><a href="pending_list.php"><i class="bi bi-clock-history nav-icons"></i>Pending List</a></li>
      </ul>
      <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
    </nav>
    <div class="btn-getstarted"><span class="bi bi-mortarboard-fill icon"><a href="stud_reg.php" style="color: black;"> Student Registration</a> </span> </div>
 
</div>


    <!-- <a class="btn-getstarted" href="stud_reg.php">Student Registration</a> -->

  </div>
</header>